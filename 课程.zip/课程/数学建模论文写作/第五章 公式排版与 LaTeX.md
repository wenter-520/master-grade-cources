## 5.1  基础

### 文档结构

**最小可编译文档**：



```latex
\documentclass[12pt,a4paper]{article}

% 导言区：加载宏包、设置参数
\usepackage{ctex}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}

\title{论文标题}
\author{作者}
\date{\today}

% 正文区
\begin{document}

\maketitle

\section{引言}
这里是正文内容。

\section{模型建立}
这里是模型部分。

\end{document}
```



**文档类**：

| 文档类    | 适用场景         |
| :-------- | :--------------- |
| `article` | 短论文、报告     |
| `report`  | 长报告、学位论文 |
| `book`    | 书籍             |
| `ctexart` | 中文文章         |

**章节命令**：



```latex
\section{一级标题}
\subsection{二级标题}
\subsubsection{三级标题}
\paragraph{段落标题}
```



------

### 宏包

**常用宏包**：

| 宏包          | 功能         |
| :------------ | :----------- |
| `ctex`        | 中文支持     |
| `amsmath`     | 数学公式增强 |
| `amssymb`     | 数学符号     |
| `amsthm`      | 定理环境     |
| `graphicx`    | 插入图片     |
| `booktabs`    | 三线表       |
| `geometry`    | 页面设置     |
| `hyperref`    | 超链接       |
| `listings`    | 代码排版     |
| `algorithm2e` | 算法伪代码   |

**加载示例**：



```latex
\usepackage[UTF8]{ctex}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage[margin=2.5cm]{geometry}
\usepackage{hyperref}
\usepackage{listings}
```



**常用设置**：



```latex
% 页面边距
\geometry{left=2.5cm, right=2.5cm, top=2.5cm, bottom=2.5cm}

% 行距
\linespread{1.5}

% 首行缩进
\setlength{\parindent}{2em}

% 图片路径
\graphicspath{{figures/}}
```



------

### 编译

**编译命令**：



```bash
pdf main.tex    # 直接生成 PDF
xe main.tex     # 支持中文和字体
mk -pdf main.tex # 自动多次编译
```



**推荐**：使用 `xe` 或 `mk`。

**编译流程**：



```tex
xe → bibtex → xe → xe
```



**常见工具**：

- **TeX Live**：跨平台；
- **MiKTeX**：Windows；
- **MacTeX**：macOS；
- **Overleaf**：在线编辑器。

------

## 5.2 数学公式排版

### 行内公式与行间公式

**行内公式**（与文字同行）：



```latex
设 $x$ 为决策变量，$f(x)$ 为目标函数。
```



效果：设 x 为决策变量，f(x) 为目标函数。

**行间公式**（单独一行，不编号）：



```latex
\[
f(x) = x^2 + 2x + 1
\]
```



**行间公式**（单独一行，编号）：



```latex
\begin{equation}
f(x) = x^2 + 2x + 1
\end{equation}
```



**引用公式**：



```latex
由式 \eqref{eq:quadratic} 可得……

\begin{equation}
f(x) = x^2 + 2x + 1
\label{eq:quadratic}
\end{equation}
```



------

### 多行公式

**对齐公式**（`align` 环境）：



```latex
\begin{align}
f(x) &= x^2 + 2x + 1 \\
     &= (x + 1)^2
\end{align}
```



**不编号对齐**（`align*`）：



```latex
\begin{align*}
f(x) &= x^2 + 2x + 1 \\
     &= (x + 1)^2
\end{align*}
```



**多行公式（一个编号）**（`split` 或 `equation` + `aligned`）：



```latex
\begin{equation}
\begin{split}
f(x) &= x^2 + 2x + 1 \\
     &= (x + 1)^2
\end{split}
\end{equation}
```



**分段函数**（`cases`）：



```latex
\begin{equation}
f(x) = 
\begin{cases}
x^2, & x \geq 0 \\
-x^2, & x < 0
\end{cases}
\end{equation}
```



**多行并列**（`gather`）：



```latex
\begin{gather}
a + b = c \\
d + e = f \\
g + h = i
\end{gather}
```



------

### 矩阵与方程组

**矩阵**（`pmatrix`、`bmatrix`、`vmatrix`）：



```latex
% 圆括号矩阵
\[
A = \begin{pmatrix}
a_{11} & a_{12} \\
a_{21} & a_{22}
\end{pmatrix}
\]

% 方括号矩阵
\[
B = \begin{bmatrix}
b_{11} & b_{12} \\
b_{21} & b_{22}
\end{bmatrix}
\]

% 行列式
\[
\det(C) = \begin{vmatrix}
c_{11} & c_{12} \\
c_{21} & c_{22}
\end{vmatrix}
\]
```



**方程组**（`cases` 或 `array`）：



```latex
\[
\begin{cases}
x + y = 3 \\
2x - y = 0
\end{cases}
\]

\[
\left\{
\begin{array}{l}
x + y = 3 \\
2x - y = 0
\end{array}
\right.
\]
```



**多行方程组**（`align`）：



```latex
\begin{align}
x + y &= 3 \label{eq:eq1} \\
2x - y &= 0 \label{eq:eq2}
\end{align}
```



------

### 定理、引理、证明

**定义定理环境**：



```latex
\usepackage{amsthm}

\newtheorem{theorem}{定理}[section]
\newtheorem{lemma}[theorem]{引理}
\newtheorem{corollary}[theorem]{推论}
\newtheorem{definition}{定义}[section]

% 证明环境
\renewcommand{\proofname}{证明}
```



**使用**：



```latex
\begin{theorem}[勾股定理]
在直角三角形中，两直角边的平方和等于斜边的平方。
\end{theorem}

\begin{proof}
设两直角边为 $a$ 和 $b$，斜边为 $c$，则 $a^2 + b^2 = c^2$。
\end{proof}

\begin{definition}[凸函数]
设 $f: C \to \mathbb{R}$，若对任意 $x, y \in C$ 和 $\theta \in [0,1]$ 有
$f(\theta x + (1-\theta)y) \leq \theta f(x) + (1-\theta) f(y)$，
则称 $f$ 为凸函数。
\end{definition}
```



------

## 5.3 符号与字体

### 希腊字母

**小写希腊字母**：



```latex
\alpha, \beta, \gamma, \delta, \epsilon, \varepsilon,
\zeta, \eta, \theta, \vartheta, \iota, \kappa,
\lambda, \mu, \nu, \xi, \pi, \varpi,
\rho, \varrho, \sigma, \varsigma, \tau, \upsilon,
\phi, \varphi, \chi, \psi, \omega
```



**大写希腊字母**：



```latex
\Gamma, \Delta, \Theta, \Lambda, \Xi, \Pi,
\Sigma, \Upsilon, \Phi, \Psi, \Omega
```



**常见示例**：



```latex
\[
\alpha, \beta, \gamma, \lambda, \mu, \sigma, \phi, \omega
\]
\[
\Gamma, \Delta, \Theta, \Lambda, \Sigma, \Omega
\]
```



------

### 运算符

**基本运算**：



```latex
+ , - , \times , \div , \pm , \mp , \cdot , \ast , \star
```



**关系运算**：



```latex
= , \neq , \approx , \equiv , \sim , \simeq , \cong , < , > , \leq , \geq
```



**集合运算**：



```latex
\in , \notin , \subset , \subseteq , \supset , \supseteq ,
\cup , \cap , \setminus , \emptyset , \varnothing
```



**大型运算符**：



```latex
\sum_{i=1}^{n} , \prod_{i=1}^{n} , \int_{a}^{b} , \iint , \iiint , \oint
```



**示例**：



```latex
\[
\sum_{i=1}^{n} x_i = x_1 + x_2 + \cdots + x_n
\]

\[
\int_{0}^{1} x^2 \, dx = \frac{1}{3}
\]

\[
\prod_{i=1}^{n} (x - x_i)
\]
```



**其他常用**：



```latex
\sqrt{x} , \sqrt[n]{x} , \frac{a}{b} , \dfrac{a}{b} , \binom{n}{k}
```



------

### 箭头

**常用箭头**：



```latex
\rightarrow , \leftarrow , \leftrightarrow ,
\Rightarrow , \Leftarrow , \Leftrightarrow ,
\uparrow , \downarrow ,
\mapsto , \longrightarrow , \Longrightarrow
```



**长箭头**：



```latex
\xrightarrow{f} , \xleftarrow{g}
```



**示例**：



```latex
\[
f: X \rightarrow Y , \quad x \mapsto f(x)
\]
\[
A \Rightarrow B , \quad A \Leftrightarrow B
\]
\[
X \xrightarrow{f} Y \xrightarrow{g} Z
\]
```



------

### 特殊符号

**常用符号**：



```latex
\forall , \exists , \nexists , \neg , \land , \lor ,
\infty , \partial , \nabla , \square , \triangle ,
\mathbb{R} , \mathbb{N} , \mathbb{Z} , \mathbb{Q} , \mathbb{C} ,
\mathcal{A} , \mathcal{B} ,
\mathbf{x} , \boldsymbol{\beta}
```



**示例**：



```latex
\[
\forall x \in \mathbb{R}, \exists y \in \mathbb{N}
\]
\[
\nabla f = \left( \frac{\partial f}{\partial x_1}, \ldots, \frac{\partial f}{\partial x_n} \right)
\]
\[
\mathbf{A} \mathbf{x} = \boldsymbol{\beta}
\]
```



------

## 5.4 论文模板

### 国赛模板

**基本结构**：



```latex
\documentclass[12pt,a4paper]{article}

\usepackage[UTF8]{ctex}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{geometry}
\usepackage{hyperref}
\usepackage{listings}

\geometry{left=2.5cm,right=2.5cm,top=2.5cm,bottom=2.5cm}
\linespread{1.5}

\title{论文标题}
\date{}

\begin{document}

% 标题
\begin{center}
{\LARGE \bf{论文标题}}
\end{center}

% 摘要
\begin{center}
\bf{摘\quad 要}
\end{center}

摘要内容……

\vspace{0.5cm}
\bf{关键词：}关键词1，关键词2，关键词3

\newpage

% 正文
\section{问题重述}
\section{模型假设}
\section{符号说明}
\section{模型建立与求解}
\section{模型检验}
\section{模型评价与推广}

\newpage
\section*{参考文献}
\begin{thebibliography}{99}
\bibitem{ref1} 姜启源, 谢金星, 叶俊. 数学模型[M]. 5版. 北京: 高等教育出版社, 2018.
\bibitem{ref2} 司守奎, 孙玺菁. 数学建模算法与应用[M]. 3版. 北京: 国防工业出版社, 2021.
\end{thebibliography}

\newpage
\appendix
\section{附录}

\end{document}
```



------

### 研赛模板

研赛（中国研究生数学建模竞赛）的模板与国赛类似，但有一些细节差异：

- 封面需要填写参赛队号、参赛密码、题目编号等；
- 摘要页格式略有不同；
- 正文格式要求类似。

**封面示例**：



```latex
\begin{titlepage}
\centering
\vspace*{2cm}

{\Huge \bf{中国研究生数学建模竞赛}}

\vspace{2cm}

{\LARGE \bf{题\quad 目：}\underline{\makebox[8cm]{题目名称}}}

\vspace{2cm}

{\Large
参赛队号：\underline{\makebox[4cm]{XXXXX}} \\
参赛密码：\underline{\makebox[4cm]{XXXXX}} \\
题目编号：\underline{\makebox[4cm]{X}}
}

\vspace{3cm}
{\large \today}
\end{titlepage}
```



------

### 美赛模板

**美赛（MCM/ICM）**使用英文，需要：

- 摘要页（Summary Sheet）单独一页；
- 正文从第 2 页开始；
- 页眉有控制号。

**示例**：



```latex
\documentclass[12pt]{article}

\usepackage{amsmath,amssymb,amsthm}
\usepackage{graphicx}
\usepackage{geometry}
\usepackage{fancyhdr}

\geometry{left=2.5cm,right=2.5cm,top=2.5cm,bottom=2.5cm}

\pagestyle{fancy}
\fancyhf{}
\fancyhead[C]{Team \# XXXXX}
\fancyfoot[C]{\thepage}

\begin{document}

% Summary Sheet
\begin{center}
{\LARGE \bf{Summary}}
\end{center}

Summary content...

\newpage

% Main body
\section{Introduction}
\section{Assumptions}
\section{Model Development}
\section{Results}
\section{Conclusion}

\end{document}
```



------

## 5.5 参考文献管理

### BibTeX

**BibTeX 文件**（`references.bib`）：

bibtex

```latex
@book{jiang2018,
  author = {姜启源 and 谢金星 and 叶俊},
  title = {数学模型},
  edition = {5},
  publisher = {高等教育出版社},
  address = {北京},
  year = {2018}
}

@book{si2021,
  author = {司守奎 and 孙玺菁},
  title = {数学建模算法与应用},
  edition = {3},
  publisher = {国防工业出版社},
  address = {北京},
  year = {2021}
}

@article{wang2020,
  author = {王某某 and 李某某},
  title = {基于改进遗传算法的车间调度优化},
  journal = {系统工程理论与实践},
  volume = {40},
  number = {5},
  pages = {1234--1245},
  year = {2020}
}
```



**引用方式**：



```latex
\cite{jiang2018}
\cite{si2021,wang2020}
```



**生成参考文献列表**：



```latex
\bibliographystyle{plain}
\bibliography{references}
```



**编译**：



```tex
xe main → bibtex main → xe main → xe main
```



------

### 引用格式

**常用样式**：

| 样式    | 格式                     |
| :------ | :----------------------- |
| `plain` | 按作者字母排序，数字引用 |
| `unsrt` | 按引用顺序，数字引用     |
| `alpha` | 作者缩写+年份            |
| `abbrv` | 缩写作者名               |

**中文格式**：可使用 `gbt7714` 宏包。



```latex
\usepackage{gbt7714}
\bibliographystyle{gbt7714-numerical}
```



------

### 常见问题

**问题 1：引用不显示**

原因：未编译 bibtex。

解决：



```bash
xe main
bibtex main
xe main
xe main
```



**问题 2：中文参考文献乱码**

原因：编码问题。

解决：确保 `.bib` 文件为 UTF-8 编码，并使用 `ctex` 宏包。

**问题 3：引用编号不连续**

原因：多次编译未清理缓存。

解决：删除 `.aux`、`.bbl`、`.blg` 文件后重新编译。

**问题 4：多个引用合并**



```latex
\cite{ref1,ref2,ref3}  % 输出 [1,2,3]
```



使用 `cite` 宏包：



```latex
\usepackage{cite}
\cite{ref1,ref2,ref3}  % 输出 [1-3]
```



------

## 5.6 Word 排版技巧

### 公式编辑器

**Word 公式编辑器**：

- 快捷键 `Alt` + `=` 插入公式；
- 支持  语法输入；
- 常用快捷键：
  - `\alpha` + 空格 → α；
  - `\sum` + 空格 → Σ；
  - `\frac` + 空格 → 分数。

** 语法输入**：

在 Word 公式编辑器中，输入 `\alpha` 后按空格，自动转换为 α。

**示例**：



```latex
\sum_{i=1}^{n} x_i
```



输入后按回车，生成求和公式。

------

### 样式设置

**创建样式**：

1. 选中文本；
2. 右键 → 样式 → 创建样式；
3. 设置字体、字号、行距、缩进。

**常用样式**：

| 样式     | 字体 | 字号 | 行距   |
| :------- | :--- | :--- | :----- |
| 正文     | 宋体 | 小四 | 1.5 倍 |
| 一级标题 | 黑体 | 三号 | 单倍   |
| 二级标题 | 黑体 | 四号 | 单倍   |
| 三级标题 | 黑体 | 小四 | 单倍   |

------

### 目录生成

**自动生成目录**：

1. 使用标题样式（标题 1、标题 2、标题 3）；
2. 引用 → 目录 → 自动目录；
3. 更新目录：右键 → 更新域。

**注意事项**：

- 标题样式必须正确应用；
- 目录更新后页码自动调整；
- 提交前更新目录。

------

### 交叉引用

**插入交叉引用**：

1. 引用 → 交叉引用；
2. 选择引用类型（图、表、公式、标题）；
3. 选择具体对象。

**示例**：



```tex
如图 1 所示……
如表 2 所示……
由式 (3) 可得……
```



**更新交叉引用**：

- 全选（Ctrl+A）；
- 按 F9 更新域。

**注意事项**：

- 图表编号使用题注（引用 → 插入题注）；
- 公式编号使用公式工具；
- 交叉引用可自动更新。

------

**Word 排版检查清单**：

- □ 

  正文使用统一字体和字号；

- □ 

  标题使用标题样式；

- □ 

  图表使用题注；

- □ 

  公式使用公式编辑器；

- □ 

  目录自动生成并更新；

- □ 

  交叉引用正确；

- □ 

  页眉页脚统一；

- □ 

  参考文献格式统一；

- □ 

  提交前更新所有域。