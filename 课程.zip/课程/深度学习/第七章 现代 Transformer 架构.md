## 7.1 RoPE 旋转位置编码

### 7.1.1 绝对位置编码的局限

原始 Transformer 使用正弦位置编码，直接加到词嵌入上：
$$
\mathbf{x}_i' = \mathbf{x}_i + \mathbf{PE}_i
$$
问题在于：

- 位置信息只在**输入层注入一次**，后续注意力层无法感知词之间的相对距离。
- 可学习位置编码有最大长度限制，训练 512 就无法外推到 1024。
- 正弦编码虽有外推潜力，但实际外推效果差。

而语言中真正重要的是**相对位置**——“这个词和那个词隔了几个词”，而非“这个词绝对在第几位”。

### 7.1.2 RoPE 的核心思想

RoPE（Rotary Position Embedding，苏剑林等，2021）的核心思想：**通过旋转 Query 和 Key 向量，使它们的点积自然包含相对位置信息。**

具体做法：将 Query 和 Key 向量的每两个维度分为一组，对每一组施加一个与位置 m*m* 相关的旋转矩阵。

### 7.1.3 二维旋转

对于二维向量 q=(q~0~,q~1~)，旋转角度 θ：
$$
\begin{pmatrix} q_0' \\ q_1' \end{pmatrix} = \begin{pmatrix} \cos\theta & -\sin\theta \\ \sin\theta & \cos\theta \end{pmatrix} \begin{pmatrix} q_0 \\ q_1 \end{pmatrix}
$$

### 7.1.4 高维 RoPE

对于 d维向量，将其分成 d/2 组，每组用不同的旋转频率。第 i组的旋转角度为：
$$
\theta_i = m \cdot \omega_i, \quad \omega_i = \frac{1}{10000^{2i/d}}
$$
其中 m是位置索引。对位置 m的 Query 向量 q~m~施加旋转：
$$
\mathbf{q}_m' = \mathbf{R}_m \mathbf{q}_m
$$
其中 R~m~是分块对角旋转矩阵：
$$
\mathbf{R}_m = \begin{pmatrix} \cos(m\omega_1) & -\sin(m\omega_1) & & & \\ \sin(m\omega_1) & \cos(m\omega_1) & & & \\ & & \cos(m\omega_2) & -\sin(m\omega_2) & \\ & & \sin(m\omega_2) & \cos(m\omega_2) & \\ & & & & \ddots \end{pmatrix}
$$

### 7.1.5 相对位置性质的推导

对位置 m的 Query 和位置 n的 Key 分别施加旋转后，点积为：
$$
(\mathbf{R}_m \mathbf{q}_m)^T (\mathbf{R}_n \mathbf{k}_n) = \mathbf{q}_m^T \mathbf{R}_m^T \mathbf{R}_n \mathbf{k}_n = \mathbf{q}_m^T \mathbf{R}_{n-m} \mathbf{k}_n
$$
关键性质：旋转矩阵的转置乘积满足：

因此点积结果**仅依赖于相对位置差 n−m**，而不依赖绝对位置 m和 n。这正是 RoPE 天然编码相对位置的根本原因。

### 7.1.6 RoPE 的优势

- **相对位置编码**：点积天然包含相对距离信息。
- **无需训练**：旋转角度由固定公式生成。
- **外推能力**：配合位置插值（PI）、NTK-aware 缩放、YaRN 等方法，可以将训练长度 4K 的模型外推到 128K 甚至更长。
- **计算高效**：只需在注意力前对 Q、K 做一次旋转。
- **无额外参数**：不像可学习位置编码需要存储 L~max⁡×d~ 的参数。

### 7.1.7 RoPE 的长度外推

**位置插值（PI）**：将位置索引缩小到训练范围内。
$$
m' = m \cdot \frac{L_{\text{train}}}{L_{\text{target}}}
$$
**NTK-aware 缩放**：调整旋转频率的基频，让高频分量衰减慢、低频分量衰减快。

**YaRN**：结合 NTK 和温度缩放，是目前效果最好的外推方案之一。

## 7.2 GQA / MQA 分组查询注意力

### 7.2.1 多头注意力的显存瓶颈

标准多头注意力（MHA）中，每个头都有独立的 Q、K、V 投影：
$$
\mathbf{Q}, \mathbf{K}, \mathbf{V} \in \mathbb{R}^{n \times d}
$$
在自回归推理时，需要缓存所有已生成 token 的 Key 和 Value（KV 缓存），缓存大小：
$$
\text{KV Cache} = 2 \times n \times d \times L \times \text{batch size} \times \text{precision}
$$

### 7.2.2 多查询注意力（MQA）

MQA（Multi-Query Attention，Shazeer 2019）：**所有 Query 头共享同一组 Key 和 Value 头**。
$$
\mathbf{Q} \in \mathbb{R}^{n \times h \times d_k}, \quad \mathbf{K}, \mathbf{V} \in \mathbb{R}^{n \times 1 \times d_k}
$$
KV 缓存减少为原来的 1/h，显存大幅降低。

**缺点**：所有头共享 KV，表达能力受限，模型质量可能下降。

### 7.2.3 分组查询注意力（GQA）

GQA（Grouped-Query Attention，Ainslie 2023）：**折中方案**——将 Query 头分成 G 组，每组内的 Query 头共享同一组 KV 头。
$$
\mathbf{Q} \in \mathbb{R}^{n \times h \times d_k}, \quad \mathbf{K}, \mathbf{V} \in \mathbb{R}^{n \times G \times d_k}
$$
其中 G<h。KV 缓存减少为原来的 G/h。

**KV 头数计算**：
$$
\text{kv\_heads} = \frac{\text{num\_attention\_heads}}{\text{groups}}
$$

### 7.2.4 三种注意力对比

| 类型 | Q 头数 | KV 头数 | KV 缓存 | 模型质量 |
| :--- | :----- | :------ | :------ | :------- |
| MHA  | *h*    | h       | 2hnd    | 最高     |
| MQA  | *h*    | 1       | 2nd     | 略低     |
| GQA  | *h*    | *G*     | 2Gnd    | 接近 MHA |

GQA 在保持质量的同时显著降低推理显存，已成为现代大模型的默认选择。

## 7.3 SwiGLU 激活函数

### 7.3.1 标准 FFN 的局限

原始 Transformer 的前馈网络：
$$
\text{FFN}(\mathbf{x}) = \mathbf{W}_2 \cdot \text{ReLU}(\mathbf{W}_1 \mathbf{x})
$$
ReLU 在负半轴输出恒为 0，信息一旦落入负半轴就完全丢失，缺乏“门控”机制来选择性地通过信息。

### 7.3.2 GLU 门控线性单元

GLU（Gated Linear Unit）引入门控机制：
$$
\text{GLU}(\mathbf{x}) = (\mathbf{W}_1 \mathbf{x}) \odot \sigma(\mathbf{W}_2 \mathbf{x})
$$
其中 ⊙ 是逐元素乘法，σ是 Sigmoid。一部分提供信号，另一部分提供 0 到 1 的门控权重。

### 7.3.3 SwiGLU

SwiGLU 将 GLU 中的 Sigmoid 替换为 SiLU（Swish）：
$$
\text{SwiGLU}(\mathbf{x}) = (\mathbf{W}_1 \mathbf{x}) \odot \text{SiLU}(\mathbf{W}_g \mathbf{x})
$$
其中：
$$
\text{SiLU}(z) = z \cdot \sigma(z)
$$
完整的 FFN：
$$
\text{FFN}_{\text{SwiGLU}}(\mathbf{x}) = \mathbf{W}_2 \left( (\mathbf{W}_1 \mathbf{x}) \odot \text{SiLU}(\mathbf{W}_g \mathbf{x}) \right)
$$

### 7.3.4 参数量调整

标准 FFN 有两个权重矩阵：W~1~∈R^d×4d^，W~2~∈R^4d×d^，参数量 8d^2^。

SwiGLU 有三个权重矩阵：W~1~,W~g~∈R^d×d~ff~^，W~2~∈R^d~ff~×d^，参数量 3⋅d⋅d~ff~。

为了保持参数量与标准 FFN 相当，中间维度从 4d缩小到：
$$
d_{\text{ff}} \approx \frac{8d}{3}
$$

### 7.3.5 优势

- 门控机制让模型能选择性通过或抑制信息。
- 平滑非单调的 SiLU 在原点附近有更好的梯度特性。
- 实践中显著提升模型质量，已成为 LLaMA、Qwen、PaLM 等模型的标配。

## 7.4 Pre-Norm 与 Post-Norm

### 7.4.1 Post-Norm

原始 Transformer 的写法，层归一化在残差相加之后：
$$
\mathbf{x}_{l+1} = \text{LayerNorm}(\mathbf{x}_l + \text{Sublayer}(\mathbf{x}_l))
$$
**问题**：梯度从深层往浅层传播时，必须经过每一层的 LayerNorm。LayerNorm 的雅可比矩阵会缩放梯度，导致深层网络难以训练，需要复杂的学习率预热。

### 7.4.2 Pre-Norm

现代大模型的写法，层归一化在子层输入之前：
$$
\mathbf{x}_{l+1} = \mathbf{x}_l + \text{Sublayer}(\text{LayerNorm}(\mathbf{x}_l))
$$
**优势**：残差连接是一条“纯净”的高速公路，梯度可以不经过任何归一化直接传回浅层。

**缺点**：残差路径上的激活值方差会随层数累积，最终需要额外一个 LayerNorm 在输出前。

### 7.4.3 理论分析

**Post-Norm 的梯度**：
$$
\frac{\partial \mathbf{x}_{l+1}}{\partial \mathbf{x}_l} = \mathbf{J}_{\text{LN}} \left( \mathbf{I} + \frac{\partial \text{Sublayer}}{\partial \mathbf{x}_l} \right)
$$
**J**~LN~ 是 LayerNorm 的雅可比，其奇异值可能小于 1，导致梯度衰减。

**Pre-Norm 的梯度**：
$$
\frac{\partial \mathbf{x}_{l+1}}{\partial \mathbf{x}_l} = \mathbf{I} + \frac{\partial \text{Sublayer}}{\partial \mathbf{x}_l}
$$
恒等项 I 保证梯度有一条值为 1 的通路，不会衰减。

### 7.4.4 实践选择

- **Post-Norm**：原始 Transformer、BERT 使用。
- **Pre-Norm**：GPT 系列、LLaMA、Qwen、DeepSeek 等现代大模型全部使用。

## 7.5 MoE 混合专家模型

### 7.5.1 动机

增大模型参数量通常能提升性能，但计算量也会同比增加。能不能**增大参数但不增加计算**？

MoE 的核心思想：将 FFN 层替换为**多个并行的“专家”**，每个 token 只激活其中少数几个专家，其余专家不参与计算。

### 7.5.2 结构

**专家**：N 个独立的 FFN，每个专家有自己的参数 W~1~^(i)^,W~2~^(i)^。

**路由器（Router/Gate）**：一个小型线性层 + Softmax，为每个 token 计算它对每个专家的偏好分数：
$$
\mathbf{g}(\mathbf{x}) = \text{Softmax}(\mathbf{W}_r \mathbf{x})
$$
其中 W~r~∈R^N×d^。

**Top-K 路由**：选择分数最高的 K个专家（通常 K=1 或 2）：
$$
\text{TopK}(\mathbf{g}(\mathbf{x})) = \{i_1, i_2, \dots, i_K\}
$$
**输出**：对选中的专家输出加权求和：
$$
\text{MoE}(\mathbf{x}) = \sum_{i \in \text{TopK}} \tilde{g}_i(\mathbf{x}) \cdot \text{Expert}_i(\mathbf{x})
$$

$$
其中 \tilde{g}_i是归一化后的路由权重。
$$

### 7.5.3 参数量与计算量

- **参数量**：N个专家，参数量放大约 N** 倍。
- **计算量**：每个 token 只激活 K个专家，计算量放大约 K倍。

典型配置：N=8，K=2（如 Mixtral 8×7B）。总参数 47B，推理时只激活 13B 的计算量。

### 7.5.4 负载均衡

**问题**：如果所有 token 都涌向同一个专家，其他专家得不到训练，MoE 退化。

**辅助损失**：鼓励专家使用均匀。常用的负载均衡损失：
$$
L_{\text{balance}} = \alpha \cdot N \cdot \sum_{i=1}^{N} f_i \cdot P_i
$$
其中 f~i~是分配给专家 i的 token 比例，P~i~是路由器分配给专家 i 的平均概率。当负载不均时，损失增大。

**其他策略**：

- 专家容量（capacity）：每个专家最多处理多少 token，超出则丢弃或传给下一个专家。
- 随机路由：训练时随机丢弃部分路由决策，增加探索。

### 7.5.5 代表模型

- **Mixtral 8×7B**：8 个专家，每次激活 2 个。
- **DeepSeek-V2/V3**：细粒度专家（专家数达百级），共享专家机制。
- **Switch Transformer**：每个 token 只激活 1 个专家（Top-1）。
- **GLaM**：64 个专家，每次激活 2 个。

### 7.5.6 优缺点

| 优点                 | 缺点                                   |
| :------------------- | :------------------------------------- |
| 参数量大但计算量小   | 训练复杂，需要负载均衡                 |
| 不同专家可学不同知识 | 推理时需要加载所有专家参数，显存占用大 |
| 可扩展到万亿参数     | 专家间通信开销大（分布式训练）         |
| 稀疏激活，推理速度快 | 路由决策可能不稳定                     |