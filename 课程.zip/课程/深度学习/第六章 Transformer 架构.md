## 6.1 自注意力与缩放点积注意力

### 6.1.1 从循环到注意力的根本转变

RNN 处理序列是**串行**的：第 t*t* 步必须等第 t−1 步算完。这带来两个根本性限制：

- **无法并行**：序列越长，训练越慢。
- **长程依赖困难**：相距很远的位置需要经过多个时间步传递信息，梯度容易衰减。

Transformer 的核心思想是：**让序列中任意两个位置直接交互，距离变为 O(1)，且所有位置可以并行计算。**

### 6.1.2 Query、Key、Value

自注意力将每个位置的输入向量通过三个不同的线性变换，映射为三个角色：

- **Query（查询）** **q**：“我在找什么信息？”
- **Key（键）** **k**：“我拥有什么信息？”
- **Value（值）** **v**：“我实际的内容是什么？”

对于输入序列 X=[x_1,…,x_n]∈R^{n×d}
$$
\mathbf{Q} = \mathbf{X} \mathbf{W}^Q, \quad \mathbf{K} = \mathbf{X} \mathbf{W}^K, \quad \mathbf{V} = \mathbf{X} \mathbf{W}^V
$$

$$
其中 W_Q,W_K,W_V 是可学习权重矩阵，维度均为 d×d_k
$$

### 6.1.3 缩放点积注意力

**第 1 步：计算注意力分数**

每个 Query 与所有 Key 做点积，衡量相关性：
$$
\mathbf{S} = \mathbf{Q} \mathbf{K}^T \in \mathbb{R}^{n \times n}
$$

$$
其中 S_{ij}=q_{i}^Tk_j。
$$

**第 2 步：缩放**
$$
除以 \sqrt{d_k}
$$
：
$$
\mathbf{S}' = \frac{\mathbf{Q} \mathbf{K}^T}{\sqrt{d_k}}
$$
**为什么要缩放**：假设 **q** 和 **k** 的每个分量独立且均值为 0、方差为 1，则点积
$$
q^{T}*=∑_{i=1}^{d_k}q_ik_i 的方差为 d_k。
$$
**当 d_k** 很大时，点积数值会很大，Softmax 后梯度趋近于 0（饱和），训练困难。除以 d_k将方差拉回 1。

**第 3 步：Softmax 归一化**
$$
\mathbf{A} = \text{softmax}\left( \frac{\mathbf{Q} \mathbf{K}^T}{\sqrt{d_k}} \right)
$$
每一行是一个概率分布，A~ij~ 表示位置 *i* 对位置 *j* 的注意力权重。

**第 4 步：加权求和**
$$
\text{Attention}(\mathbf{Q}, \mathbf{K}, \mathbf{V}) = \text{softmax}\left( \frac{\mathbf{Q} \mathbf{K}^T}{\sqrt{d_k}} \right) \mathbf{V}
$$
输出矩阵的每一行是 Value 的加权和，权重由 Query 和 Key 的相似度决定。

### 6.1.4 自注意力的计算复杂度

- $$
  注意力矩阵 QK^T：O(n^2d_k)。
  $$

- $$
  Softmax：O(n^2)。
  $$

- $$
  加权求和：O(n^2d_v)。
  $$

总复杂度为 O(n^2^d)，**对序列长度 n 是平方级**。这是 Transformer 处理长序列的主要瓶颈，催生了后续大量稀疏注意力、线性注意力工作。

## 6.2 多头注意力

### 6.2.1 动机

单个注意力头只能学习一种“关注模式”。但语言中需要同时关注多种关系：语法依赖、语义相似、位置邻近、指代关系等。多头注意力让模型在**多个子空间**中并行学习不同的注意力模式。

### 6.2.2 计算过程

将 Query、Key、Value 投影到 h* 个低维子空间（每个头维度为 d_k=d/h），每个头独立计算注意力，最后拼接并投影回原始维度：
$$
\text{head}_i = \text{Attention}(\mathbf{Q} \mathbf{W}_i^Q, \mathbf{K} \mathbf{W}_i^K, \mathbf{V} \mathbf{W}_i^V)
$$

$$
\text{MultiHead}(\mathbf{Q}, \mathbf{K}, \mathbf{V}) = \text{Concat}(\text{head}_1, \dots, \text{head}_h) \mathbf{W}^O
$$

### 6.2.3 参数量与计算量

**参数量**（每个多头注意力层）：
$$
\text{Params} = 4 \times d^2 = (h \times 3 \times d \times d_k) + d \times d
$$
其中前三个 d^2^来自 W~Q~,W~K~,W~V~，第四个来自 W~O~。

**计算量与单头几乎相同**：因为每个头的维度缩小为 d/h，总计算量不变。

### 6.2.4 各头的分工

研究表明，不同头确实学到了不同模式：

- 有的头关注**相邻位置**。
- 有的头关注**句法依赖**（如动词-主语）。
- 有的头关注**罕见词或实体**。
- 有的头充当“无操作”，注意力分布接近均匀。

但并非所有头都必要，剪枝部分头对性能影响很小。

## 6.3 位置编码

### 6.3.1 为什么需要位置编码

自注意力对输入序列是**置换等变**的：打乱输入顺序，输出只是相应打乱，模型本身无法区分顺序。但语言中顺序极其重要（“猫追狗”与“狗追猫”完全不同）。必须显式注入位置信息。

### 6.3.2 正弦位置编码

原始 Transformer 使用固定的正弦/余弦函数生成位置编码：
$$
PE_{(pos, 2i)} = \sin\left( \frac{pos}{10000^{2i/d}} \right)
$$

$$
PE_{(pos, 2i+1)} = \cos\left( \frac{pos}{10000^{2i/d}} \right)
$$

其中 pos 是位置索引，i是维度索引，d是模型维度。

**性质**：

- 每个维度对应一个不同频率的正弦波。
- 相对位置可以通过线性变换表示：PE~pos+k~可以写成 PE~pos~的线性函数。
- 可以外推到比训练时更长的序列（但效果会下降）。

**注入方式**：直接加到词嵌入上：
$$
\mathbf{x}_i' = \mathbf{x}_i + \mathbf{PE}_i
$$

### 6.3.3 可学习位置编码

另一种做法是将位置编码作为可学习参数：
$$
\mathbf{P} \in \mathbb{R}^{L_{\max} \times d}
$$
其中 L_max⁡ 是预设的最大序列长度。BERT、GPT-2 使用这种方式。

**优点**：更灵活，能适应具体任务。
**缺点**：无法外推到训练时未见过的长度。

### 6.3.4 相对位置编码

绝对位置编码只告诉模型“我在第几个位置”，但许多任务真正需要的是“两个位置相距多远”。相对位置编码直接建模相对距离。

**基本形式**：注意力分数中加入相对位置偏置：
$$
e_{ij} = \frac{\mathbf{q}_i^T \mathbf{k}_j}{\sqrt{d_k}} + b_{i-j}
$$
其中 b_{i−j}是相对位置 i−j对应的可学习偏置。

**T5 的相对位置偏置**：将相对距离分成若干桶，每个桶有一个可学习偏置。

**RoPE（旋转位置编码）**：通过旋转 Query 和 Key 向量，使点积自然包含相对位置信息。这是 LLaMA、Qwen 等现代模型的主流方案，将在第七章详细展开。

## 6.4 编码器-解码器架构

### 6.4.1 编码器

编码器由 N 个相同的层堆叠。每层包含两个子层：

1. **多头自注意力**：每个位置关注所有位置。
2. **前馈网络（FFN）**：逐位置独立的两层全连接网络。

每个子层后接**残差连接 + 层归一化**：
$$
\mathbf{z} = \text{LayerNorm}(\mathbf{x} + \text{Sublayer}(\mathbf{x}))
$$
**前馈网络**：
$$
\text{FFN}(\mathbf{x}) = \mathbf{W}_2 \cdot \text{ReLU}(\mathbf{W}_1 \mathbf{x} + \mathbf{b}_1) + \mathbf{b}_2
$$
中间维度通常是 4*d*。

### 6.4.2 解码器

解码器也由 N 个相同的层堆叠，但每层包含**三个**子层：

1. **掩码多头自注意力**：每个位置只能关注它之前的位置（含自身）。
2. **编码器-解码器注意力（交叉注意力）**：Query 来自解码器，Key 和 Value 来自编码器输出。
3. **前馈网络**。

### 6.4.3 交叉注意力

交叉注意力让解码器在生成每个 token 时，能够“回看”编码器输出的整个输入序列：
$$
\mathbf{Q} = \mathbf{H}_{\text{dec}} \mathbf{W}^Q, \quad \mathbf{K} = \mathbf{H}_{\text{enc}} \mathbf{W}^K, \quad \mathbf{V} = \mathbf{H}_{\text{enc}} \mathbf{W}^V
$$
其中：
$$
H_{dec}：解码器当前层的输入。
$$

$$
H_{enc}：编码器的最终输出。
$$

交叉注意力的注意力权重矩阵可直接可视化为**源-目标对齐**，类似于第五章的 Seq2Seq 注意力。

### 6.4.4 三种注意力对比

| 类型         | Query 来源 | Key/Value 来源 | 出现位置               |
| :----------- | :--------- | :------------- | :--------------------- |
| 自注意力     | 当前层     | 当前层         | 编码器、解码器第一子层 |
| 掩码自注意力 | 当前层     | 当前层         | 解码器第一子层         |
| 交叉注意力   | 解码器     | 编码器输出     | 解码器第二子层         |

## 6.5 掩码自注意力与因果掩码

### 6.5.1 因果掩码的动机

解码器在生成第 t个 token 时，**只能看到已生成的前 t−1 个 token**，不能“偷看”未来的 token。但在训练时，整个目标序列是同时输入的（Teacher Forcing），如果不加限制，位置 t的注意力会看到位置 t+1,t+2,…，造成信息泄露。

### 6.5.2 掩码矩阵

因果掩码是一个上三角矩阵（不含对角线），在 Softmax 之前加到注意力分数上：
$$
\text{Mask}_{ij} = \begin{cases} 0 & j \leq i \\ -\infty & j > i \end{cases}
$$
对于长度 5 的序列：
$$
\begin{bmatrix}
0 & -\infty & -\infty & -\infty & -\infty \\
0 & 0 & -\infty & -\infty & -\infty \\
0 & 0 & 0 & -\infty & -\infty \\
0 & 0 & 0 & 0 & -\infty \\
0 & 0 & 0 & 0 & 0
\end{bmatrix}
$$
加到注意力分数上后，Softmax 中被掩码的位置 e^{−∞}→0，权重完全为零。

### 6.5.3 掩码注意力公式

$$
\text{MaskedAttention}(\mathbf{Q}, \mathbf{K}, \mathbf{V}) = \text{softmax}\left( \frac{\mathbf{Q} \mathbf{K}^T}{\sqrt{d_k}} + \mathbf{M} \right) \mathbf{V}
$$

其中 **M** 是掩码矩阵。

### 6.5.4 Padding 掩码

除了因果掩码，还有 **Padding 掩码**：对于变长序列，短序列的 padding 位置不应参与注意力计算。Padding 掩码将注意力分数在对应位置设为 −∞：
$$
\text{Mask}_{ij}^{\text{pad}} = \begin{cases} -\infty & \text{位置 } j \text{ 是 padding} \\ 0 & \text{否则} \end{cases}
$$
两种掩码可以叠加使用。

## 6.6 残差连接与层归一化

### 6.6.1 残差连接

每个子层的输出加上子层的输入：
$$
\mathbf{x}_{l+1} = \mathbf{x}_l + \text{Sublayer}(\mathbf{x}_l)
$$
**作用**：

- 提供梯度高速公路，缓解深层网络的梯度消失。
- 让每个子层只需学习“增量修正”，而非从零学起。
- Transformer 可以堆叠几十到上百层，残差连接是基础。

### 6.6.2 层归一化

对单个样本的所有特征做标准化：
$$
\mu = \frac{1}{d} \sum_{j=1}^{d} x_j
$$

$$
\sigma^2 = \frac{1}{d} \sum_{j=1}^{d} (x_j - \mu)^2
$$

$$
\hat{x}_j = \frac{x_j - \mu}{\sqrt{\sigma^2 + \epsilon}}
$$

$$
y_j = \gamma_j \hat{x}_j + \beta_j
$$

其中 γ*,*β 是可学习的缩放和偏移参数。

**为什么不用 BatchNorm**：

- BatchNorm 依赖 batch 内统计量，序列任务中 batch 大小和序列长度可变，统计不稳定。
- 推理时 BatchNorm 需要全局滑动平均，而序列任务的分布可能随长度变化。
- LayerNorm 对每个样本独立计算，与 batch 无关，训练和推理行为一致。

### 6.6.3 Post-Norm vs Pre-Norm

**原始 Transformer（Post-Norm）**：层归一化在残差相加之后。
$$
\mathbf{x}_{l+1} = \text{LayerNorm}(\mathbf{x}_l + \text{Sublayer}(\mathbf{x}_l))
$$
**现代主流（Pre-Norm）**：层归一化在子层输入之前。
$$
\mathbf{x}_{l+1} = \mathbf{x}_l + \text{Sublayer}(\text{LayerNorm}(\mathbf{x}_l))
$$
**Pre-Norm 的优势**：

- 梯度可以沿残差连接直接传到底层，不经过层归一化。
- 深层网络训练更稳定，不需要复杂的学习率预热。
- 缺点是最终需要额外一个 LayerNorm。

现代大模型（GPT、LLaMA、Qwen）几乎全部使用 Pre-Norm。

------

## 6.7 Transformer 整体参数量

以标准 Transformer（无共享权重）为例，参数量估算：

**嵌入层**：V×d（*V* 是词表大小）。

**每个编码器层**：

- 多头自注意力：4d^2^。
- 前馈网络：2×4d^2^==8d^2^。
- 层归一化：4d。
- 合计约 12d^2^。

**每个解码器层**：

- 掩码自注意力：4d^2^。
- 交叉注意力：4d^2^。
- 前馈网络：8d^2^。
- 合计约 16d^2^。

**总参数量**：
$$
\text{Params} \approx V \cdot d + N_{\text{enc}} \cdot 12 d^2 + N_{\text{dec}} \cdot 16 d^2
$$
（不含输出层和位置编码，若输出层与嵌入层共享权重则不计。）