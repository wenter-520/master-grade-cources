## 2.1 AHP 的基本原理

### 层次结构模型

**层次分析法（AHP）**由 Saaty 于 20 世纪 70 年代提出，是一种将定性问题定量化的多准则决策方法。

**核心思想**：将复杂问题分解为有序的层次结构，通过两两比较确定各因素权重，最终综合排序。

**层次结构**：



```tex
目标层（Goal）：       综合评价目标
                        ↓
准则层（Criteria）：  准则1    准则2    准则3
                        ↓       ↓       ↓
方案层（Alternatives）：方案1  方案2  方案3
```



**数学表达**：

- 目标层：唯一的决策目标 G；
- 准则层：m 个准则 C~1~, C~2~, …, C~m~；
- 方案层：n 个方案 A~1~, A~2~, …, A~n~。

**层次结构的要求**：

- 每一层的元素不超过 9 个（避免判断矩阵过大）；
- 同一层元素相互独立；
- 层间关系明确。

------

### 判断矩阵

**判断矩阵**：对同一层的元素进行两两比较，构造矩阵 A = (a~ij~)~m×m~。


$$
\mathbf{A} = 
\begin{pmatrix}
a_{11} & a_{12} & \dots & a_{1m} \\
a_{21} & a_{22} & \dots & a_{2m} \\
\vdots & \vdots & \ddots & \vdots \\
a_{m1} & a_{m2} & \dots & a_{mm}
\end{pmatrix}
$$


其中 a~ij~ 表示元素 i 相对于元素 j 的重要程度。

**判断矩阵的性质**：

- **正互反性**：


$$
a_{ij} > 0, \quad a_{ji} = \frac{1}{a_{ij}}
$$


- **对角线为 1**：


$$
a_{ii} = 1, \quad \forall i
$$


- **理想一致性**（若判断完全一致）：


$$
a_{ij} = a_{ik} \cdot a_{kj}, \quad \forall i, j, k
$$


实际判断矩阵通常不满足完全一致性，需检验。

------

### 权重计算

**目标**：从判断矩阵 A 中计算权重向量 w = (w~1~, w~2~, …, w~m~)^T^。

**特征值法**（理论依据）：

若判断矩阵完全一致，则


$$
\mathbf{A} \mathbf{w} = m \mathbf{w}
$$


即 w 是 A 的特征向量，m 是特征值。

实际操作中，求 A 的最大特征值 λ~max~ 及对应的特征向量，归一化后作为权重。

**数学表达**：


$$
\mathbf{A} \mathbf{w} = \lambda_{\max} \mathbf{w}
$$


归一化：


$$
w_j = \frac{v_j}{\sum_{k=1}^m v_k}
$$


其中 v 为 λ~max~ 对应的特征向量。

------

### 一致性检验

**目的**：检验判断矩阵的逻辑一致性。

**一致性指标（CI）**：


$$
CI = \frac{\lambda_{\max} - m}{m - 1}
$$


**随机一致性指标（RI）**：根据矩阵阶数查表。

| m    | 1    | 2    | 3    | 4    | 5    | 6    | 7    | 8    | 9    |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RI   | 0    | 0    | 0.58 | 0.90 | 1.12 | 1.24 | 1.32 | 1.41 | 1.45 |

**一致性比率（CR）**：


$$
CR = \frac{CI}{RI}
$$


**判断标准**：

- CR < 0.1：一致性可接受；
- CR ≥ 0.1：需调整判断矩阵。

------

## 2.2 层次结构模型的建立

### 目标层

**目标层**：唯一的决策目标，位于层次结构最上方。

**示例**：

- 选择最佳旅游目的地；
- 评价城市宜居性；
- 选择最优供应商。

**目标层的数学表达**：


$$
G = \text{决策目标}
$$


------

### 准则层

**准则层**：影响决策的主要因素，通常分为一级准则和二级准则。

**建立步骤**：

1. 确定一级准则（3—7 个）；
2. 每个一级准则下分解二级准则；
3. 确保准则之间相互独立。

**示例**（选择旅游目的地）：

一级准则：

- 经济性 C~1~；
- 景观 C~2~；
- 交通 C~3~；
- 食宿 C~4~。

二级准则（经济性下）：

- 交通费用 C~11~；
- 门票费用 C~12~；
- 住宿费用 C~13~。

------

### 方案层

**方案层**：待评价或选择的备选方案。

**数学表达**：


$$
A = \{A_1, A_2, \dots, A_n\}
$$


**示例**：

- 方案 A~1~：城市 1；
- 方案 A~2~：城市 2；
- 方案 A~3~：城市 3。

**方案层的确定**：

- 方案应覆盖决策空间；
- 方案数量适中（3—9 个）；
- 方案之间互斥。

------

## 2.3 判断矩阵的构造

### 1—9 标度法

**Saaty 1—9 标度**：用 1—9 的整数表示相对重要性。

| 标度 a~ij~ | 含义                                             |
| :--------- | :----------------------------------------------- |
| 1          | i 与 j 同等重要                                  |
| 3          | i 比 j 稍重要                                    |
| 5          | i 比 j 明显重要                                  |
| 7          | i 比 j 强烈重要                                  |
| 9          | i 比 j 极端重要                                  |
| 2, 4, 6, 8 | 上述相邻判断的中间值                             |
| 倒数       | 若 i 与 j 之比为 a~ij~，则 j 与 i 之比为 1/a~ij~ |

**示例**（4 个准则的判断矩阵）：

|      | C~1~ | C~2~ | C~3~ | C~4~ |
| :--- | :--- | :--- | :--- | :--- |
| C~1~ | 1    | 3    | 5    | 7    |
| C~2~ | 1/3  | 1    | 3    | 5    |
| C~3~ | 1/5  | 1/3  | 1    | 3    |
| C~4~ | 1/7  | 1/5  | 1/3  | 1    |

**含义**：

- C~1~ 比 C~2~ 稍重要（3）；
- C~1~ 比 C~3~ 明显重要（5）；
- C~1~ 比 C~4~ 强烈重要（7）。

------

### 判断矩阵的性质

**性质 1：正互反性**


$$
a_{ij} > 0, \quad a_{ji} = \frac{1}{a_{ij}}
$$


**性质 2：对角线为 1**


$$
a_{ii} = 1
$$


**性质 3：理想一致性**


$$
a_{ij} = a_{ik} a_{kj}, \quad \forall i, j, k
$$


**性质 4：特征值性质**

若判断矩阵完全一致，则 λ~max~ = m，其余特征值为 0。

若判断矩阵不完全一致，则 λ~max~ > m。

**一致性偏差**：


$$
\lambda_{\max} - m \geq 0
$$


偏差越大，一致性越差。

------

### 专家打分与群体决策

**专家打分**：邀请多位专家独立构造判断矩阵。

**群体决策方法**：

**方法一：几何平均法**

对 k 位专家的判断矩阵取几何平均：


$$
a_{ij} = \left( \prod_{l=1}^k a_{ij}^{(l)} \right)^{1/k}
$$


其中 a~ij~^(l)^ 为第 l 位专家的判断值。

**方法二：算术平均法**


$$
a_{ij} = \frac{1}{k} \sum_{l=1}^k a_{ij}^{(l)}
$$


**注意**：算术平均可能破坏互反性，几何平均更好。

**方法三：权重平均法**

分别计算各位专家的权重，再平均：


$$
w_j = \frac{1}{k} \sum_{l=1}^k w_j^{(l)}
$$


**专家权重**：可根据专家权威性赋予不同权重。

------

## 2.4 权重计算方法

### 特征值法

**步骤**：

1. 计算判断矩阵 A 的最大特征值 λ~max~；
2. 求 λ~max~ 对应的特征向量 v；
3. 归一化得到权重 w。

**数学表达**：


$$
\mathbf{A} \mathbf{v} = \lambda_{\max} \mathbf{v}
$$



$$
w_j = \frac{v_j}{\sum_{k=1}^m v_k}
$$


**Python 示例**：



```python
import numpy as np

def eigen_weight(A):
    eigenvalues, eigenvectors = np.linalg.eig(A)
    idx = np.argmax(eigenvalues.real)
    lambda_max = eigenvalues[idx].real
    v = eigenvectors[:, idx].real
    w = v / v.sum()
    return w, lambda_max

A = np.array([
    [1, 3, 5, 7],
    [1/3, 1, 3, 5],
    [1/5, 1/3, 1, 3],
    [1/7, 1/5, 1/3, 1]
])

w, lambda_max = eigen_weight(A)
print(f"权重: {w}")
print(f"最大特征值: {lambda_max:.4f}")
```



------

### 几何平均法（方根法）

**步骤**：

1. 计算判断矩阵每行元素的几何平均：


$$
\bar{w}_i = \left( \prod_{j=1}^m a_{ij} \right)^{1/m}
$$


1. 归一化：


$$
w_i = \frac{\bar{w}_i}{\sum_{k=1}^m \bar{w}_k}
$$


**优点**：计算简单，不需计算特征值。

**Python 示例**：



```python
def geometric_weight(A):
    m = A.shape[0]
    w_bar = np.prod(A, axis=1) ** (1/m)
    w = w_bar / w_bar.sum()
    return w

w = geometric_weight(A)
print(f"几何平均法权重: {w}")
```



------

### 算术平均法（和积法）

**步骤**：

1. 对判断矩阵每列归一化：


$$
\bar{a}_{ij} = \frac{a_{ij}}{\sum_{k=1}^m a_{kj}}
$$


1. 对归一化矩阵按行求和：


$$
\bar{w}_i = \sum_{j=1}^m \bar{a}_{ij}
$$


1. 再归一化：


$$
w_i = \frac{\bar{w}_i}{\sum_{k=1}^m \bar{w}_k}
$$


**Python 示例**：



```python
def arithmetic_weight(A):
    m = A.shape[0]
    A_norm = A / A.sum(axis=0)
    w = A_norm.sum(axis=1)
    w = w / w.sum()
    return w

w = arithmetic_weight(A)
print(f"算术平均法权重: {w}")
```



------

### 最小二乘法

**思想**：寻找权重 w 使判断矩阵 A 与理论矩阵 w~i~/w~j~ 的偏差最小。

**优化问题**：


$$
\min \sum_{i=1}^m \sum_{j=1}^m \left( a_{ij} - \frac{w_i}{w_j} \right)^2
$$


约束：


$$
\sum_{i=1}^m w_i = 1, \quad w_i > 0
$$


**对数形式**：


$$
\min \sum_{i=1}^m \sum_{j=1}^m \left( \ln a_{ij} - \ln w_i + \ln w_j \right)^2
$$


**求解**：用数值优化方法。

**Python 示例**：



```python
from scipy.optimize import minimize

def least_squares_weight(A):
    m = A.shape[0]
    
    def objective(w):
        w = np.abs(w)  # 保证正
        w = w / w.sum()
        loss = 0
        for i in range(m):
            for j in range(m):
                loss += (A[i, j] - w[i] / w[j]) ** 2
        return loss
    
    x0 = np.ones(m) / m
    cons = [{'type': 'eq', 'fun': lambda w: np.sum(np.abs(w)) - 1}]
    bounds = [(1e-6, 1)] * m
    
    res = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=cons)
    w = np.abs(res.x)
    return w / w.sum()

w = least_squares_weight(A)
print(f"最小二乘法权重: {w}")
```



------

### 四种方法比较

| 方法       | 优点     | 缺点     | 适用场景   |
| :--------- | :------- | :------- | :--------- |
| 特征值法   | 理论严谨 | 计算复杂 | 通用       |
| 几何平均法 | 简单     | 近似     | 快速估算   |
| 算术平均法 | 最简单   | 近似     | 快速估算   |
| 最小二乘法 | 拟合最优 | 需优化   | 精度要求高 |

**实践建议**：特征值法最常用，几何平均法适合手工计算。

------

## 2.5 一致性检验

### 一致性指标 CI

**定义**：


$$
CI = \frac{\lambda_{\max} - m}{m - 1}
$$


**性质**：

- CI = 0：判断矩阵完全一致；
- CI 越大：一致性越差；
- CI 与矩阵阶数 m 有关。

**示例**（4 阶矩阵，λ~max~ = 4.12）：


$$
CI = \frac{4.12 - 4}{4 - 1} = 0.04
$$


------

### 随机一致性指标 RI

**定义**：随机生成的判断矩阵的一致性指标的平均值。

**Saaty 给出的 RI 值**：

| m    | 1    | 2    | 3    | 4    | 5    | 6    | 7    | 8    | 9    | 10   | 11   |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RI   | 0    | 0    | 0.58 | 0.90 | 1.12 | 1.24 | 1.32 | 1.41 | 1.45 | 1.49 | 1.51 |

**注意**：

- m = 1, 2 时，判断矩阵总是一致，RI = 0；
- m 越大，RI 越大。

------

### 一致性比率 CR

**定义**：


$$
CR = \frac{CI}{RI}
$$


**判断标准**：

- CR < 0.1：一致性可接受；
- CR ≥ 0.1：需调整判断矩阵。

**示例**（m = 4，CI = 0.04）：


$$
CR = \frac{0.04}{0.90} = 0.044 < 0.1 \quad \text{通过}
$$


------

### 判断标准

**一致性检验流程**：

1. 计算 λ~max~；
2. 计算 CI；
3. 查表得 RI；
4. 计算 CR；
5. 若 CR < 0.1，通过；否则调整判断矩阵。

**调整方法**：

- 重新审视判断，修正矛盾之处；
- 调整不一致性最大的元素；
- 重新构造判断矩阵。

**Python 示例**：



```python
def consistency_check(A):
    m = A.shape[0]
    w, lambda_max = eigen_weight(A)
    CI = (lambda_max - m) / (m - 1)
    
    RI_dict = {1: 0, 2: 0, 3: 0.58, 4: 0.90, 5: 1.12,
               6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45,
               10: 1.49, 11: 1.51}
    RI = RI_dict.get(m, 1.51)
    
    CR = CI / RI if RI > 0 else 0
    return CI, RI, CR, lambda_max

CI, RI, CR, lambda_max = consistency_check(A)
print(f"λ_max = {lambda_max:.4f}")
print(f"CI = {CI:.4f}, RI = {RI}, CR = {CR:.4f}")
print(f"一致性检验: {'通过' if CR < 0.1 else '不通过'}")
```



------

## 2.6 层次总排序与决策

### 合成权重计算

**层次总排序**：从目标层到方案层，逐层合成权重。

**数学表达**：

设准则层对目标层的权重为 w^(1)^ = (w~1~^(1)^, …, w~m~^(1)^)^T^。

方案层对第 k 个准则的权重为 w~k~^(2)^ = (w~1k~^(2)^, …, w~nk~^(2)^)^T^。

则方案 i 的合成权重为：


$$
W_i = \sum_{k=1}^m w_k^{(1)} \cdot w_{ik}^{(2)}
$$


**矩阵形式**：


$$
\mathbf{W} = \mathbf{w}^{(2)} \mathbf{w}^{(1)}
$$


其中 w^(2)^ 为 n×m 矩阵，w^(1)^ 为 m×1 向量。

**示例**：

准则层权重：w^(1)^ = (0.5, 0.3, 0.2)^T^；

方案层对准则 1、2、3 的权重：


$$
\mathbf{w}^{(2)} = 
\begin{pmatrix}
0.6 & 0.3 & 0.2 \\
0.3 & 0.5 & 0.3 \\
0.1 & 0.2 & 0.5
\end{pmatrix}
$$


合成权重：


$$
\mathbf{W} = 
\begin{pmatrix}
0.6 & 0.3 & 0.2 \\
0.3 & 0.5 & 0.3 \\
0.1 & 0.2 & 0.5
\end{pmatrix}
\begin{pmatrix}
0.5 \\ 0.3 \\ 0.2
\end{pmatrix}
= 
\begin{pmatrix}
0.43 \\ 0.36 \\ 0.21
\end{pmatrix}
$$


方案 1 最优。

------

### 总排序一致性检验

**总排序一致性检验**：


$$
CR_{\text{total}} = \frac{CI_{\text{total}}}{RI_{\text{total}}}
$$


其中


$$
CI_{\text{total}} = \sum_{k=1}^m w_k^{(1)} \cdot CI_k^{(2)}
$$



$$
RI_{\text{total}} = \sum_{k=1}^m w_k^{(1)} \cdot RI_k^{(2)}
$$


**判断标准**：CR~total~ < 0.1 通过。

**含义**：CI~k~^(2)^ 为第 k 个准则下方案层判断矩阵的一致性指标，RI~k~^(2)^ 为对应的随机一致性指标。

------

### 最优方案选择

**步骤**：

1. 计算合成权重 W；
2. 总排序一致性检验；
3. 选择权重最大的方案。

**决策规则**：


$$
A^* = \arg\max_i W_i
$$


**结果分析**：

- 最优方案的得分；
- 各方案的排序；
- 敏感性分析。

**Python 示例**：



```python
import numpy as np

# 准则层权重（假设已计算）
w1 = np.array([0.5, 0.3, 0.2])

# 方案层对每个准则的权重
w2 = np.array([
    [0.6, 0.3, 0.2],
    [0.3, 0.5, 0.3],
    [0.1, 0.2, 0.5]
])

# 合成权重
W = w2 @ w1
print(f"合成权重: {W}")
print(f"最优方案: A{np.argmax(W) + 1}")

# 总排序一致性检验
CI_k = [0.02, 0.03, 0.01]  # 假设
RI_k = [0.58, 0.58, 0.58]  # 假设 m=3

CI_total = np.sum(w1 * CI_k)
RI_total = np.sum(w1 * RI_k)
CR_total = CI_total / RI_total
print(f"CI_total = {CI_total:.4f}, RI_total = {RI_total:.4f}")
print(f"CR_total = {CR_total:.4f}")
print(f"总排序一致性: {'通过' if CR_total < 0.1 else '不通过'}")
```



------

## 2.7 AHP 的改进与扩展

### 模糊 AHP

**思想**：用三角模糊数代替精确数，处理判断的模糊性。

**三角模糊数**：


$$
\tilde{a}_{ij} = (l_{ij}, m_{ij}, u_{ij})
$$


其中 l ≤ m ≤ u，m 为最可能值。

**模糊运算**：

- 加法：


$$
(l_1, m_1, u_1) + (l_2, m_2, u_2) = (l_1 + l_2, m_1 + m_2, u_1 + u_2)
$$


- 乘法：


$$
(l_1, m_1, u_1) \times (l_2, m_2, u_2) = (l_1 l_2, m_1 m_2, u_1 u_2)
$$


- 倒数：


$$
(l, m, u)^{-1} = (1/u, 1/m, 1/l)
$$


**模糊权重计算**：


$$
\tilde{w}_i = \left( \prod_{j=1}^m \tilde{a}_{ij} \right)^{1/m} \Big/ \sum_{k=1}^m \left( \prod_{j=1}^m \tilde{a}_{kj} \right)^{1/m}
$$


**解模糊**：


$$
w_i = \frac{l_i + m_i + u_i}{3}
$$


------

### 区间 AHP

**思想**：用区间数代替精确数。

**区间判断矩阵**：


$$
\tilde{a}_{ij} = [a_{ij}^L, a_{ij}^U]
$$


**区间权重计算**：

求解区间特征值问题：


$$
\mathbf{A}^L \mathbf{w}^L \leq \lambda \mathbf{w}^L
$$



$$
\mathbf{A}^U \mathbf{w}^U \geq \lambda \mathbf{w}^U
$$


**应用**：专家意见不一致时，用区间表示。

------

### 群组 AHP

**思想**：综合多位专家的判断。

**方法一：聚合判断矩阵**

先聚合判断矩阵，再计算权重：


$$
\mathbf{A} = f(\mathbf{A}^{(1)}, \dots, \mathbf{A}^{(k)})
$$


**方法二：聚合权重**

先分别计算权重，再聚合：


$$
\mathbf{w} = f(\mathbf{w}^{(1)}, \dots, \mathbf{w}^{(k)})
$$


**常用聚合函数**：

- 算术平均；
- 几何平均；
- 加权平均（按专家权威性）。

**群组一致性检验**：

各专家判断矩阵的一致性以及群组聚合后的一致性都需检验。

------

## 2.8 AHP 建模案例

### 案例 1：旅游目的地选择

**问题**：选择最佳旅游目的地，3 个候选城市 A、B、C。准则：经济性、景观、交通、食宿。

**步骤**：

**第一步：建立层次结构**



```tex
目标层：选择最佳旅游目的地
准则层：经济性 C1，景观 C2，交通 C3，食宿 C4
方案层：城市 A，城市 B，城市 C
```



**第二步：构造判断矩阵**

准则层判断矩阵：

|      | C~1~ | C~2~ | C~3~ | C~4~ |
| :--- | :--- | :--- | :--- | :--- |
| C~1~ | 1    | 3    | 5    | 7    |
| C~2~ | 1/3  | 1    | 3    | 5    |
| C~3~ | 1/5  | 1/3  | 1    | 3    |
| C~4~ | 1/7  | 1/5  | 1/3  | 1    |

**第三步：计算权重与一致性检验**

**Python 实现**：



```python
import numpy as np
import pandas as pd

def ahp_full(criteria_matrix, alternative_matrices, criteria_names, alternative_names):
    """
    criteria_matrix: 准则层判断矩阵
    alternative_matrices: 方案层对每个准则的判断矩阵列表
    """
    m = len(criteria_names)
    n = len(alternative_names)
    
    # 准则层权重
    w_criteria, lambda_max = eigen_weight(criteria_matrix)
    CI = (lambda_max - m) / (m - 1)
    RI_dict = {1:0, 2:0, 3:0.58, 4:0.90, 5:1.12,
               6:1.24, 7:1.32, 8:1.41, 9:1.45}
    RI = RI_dict.get(m, 1.45)
    CR = CI / RI if RI > 0 else 0
    
    print("准则层权重:")
    for name, w in zip(criteria_names, w_criteria):
        print(f"  {name}: {w:.4f}")
    print(f"  λ_max = {lambda_max:.4f}, CI = {CI:.4f}, CR = {CR:.4f}")
    print(f"  一致性: {'通过' if CR < 0.1 else '不通过'}\n")
    
    # 方案层权重
    w_alt = np.zeros((n, m))
    for k, (A_k, name) in enumerate(zip(alternative_matrices, criteria_names)):
        w_k, lam_k = eigen_weight(A_k)
        w_alt[:, k] = w_k
        CI_k = (lam_k - n) / (n - 1)
        RI_k = RI_dict.get(n, 0.58)
        CR_k = CI_k / RI_k if RI_k > 0 else 0
        print(f"{name} 下方案权重: {w_k}, CR = {CR_k:.4f}")
    
    # 合成权重
    W = w_alt @ w_criteria
    print(f"\n合成权重:")
    for name, w in zip(alternative_names, W):
        print(f"  {name}: {w:.4f}")
    print(f"最优方案: {alternative_names[np.argmax(W)]}")
    
    return W

# 数据
criteria_names = ['经济性', '景观', '交通', '食宿']
alternative_names = ['城市A', '城市B', '城市C']

criteria_matrix = np.array([
    [1, 3, 5, 7],
    [1/3, 1, 3, 5],
    [1/5, 1/3, 1, 3],
    [1/7, 1/5, 1/3, 1]
])

alt_matrices = [
    # 经济性
    np.array([[1, 3, 5], [1/3, 1, 3], [1/5, 1/3, 1]]),
    # 景观
    np.array([[1, 1/3, 1/5], [3, 1, 1/3], [5, 3, 1]]),
    # 交通
    np.array([[1, 1, 3], [1, 1, 3], [1/3, 1/3, 1]]),
    # 食宿
    np.array([[1, 2, 3], [1/2, 1, 2], [1/3, 1/2, 1]])
]

W = ahp_full(criteria_matrix, alt_matrices, criteria_names, alternative_names)
```



**结果解读**：

- 准则层权重：经济性 0.58、景观 0.25、交通 0.11、食宿 0.06；
- 合成权重显示城市 A 或 B 最优；
- 一致性检验全部通过。

------

### 案例 2：供应商选择

**问题**：某企业选择最优供应商，3 个候选供应商 S1、S2、S3。准则：质量、价格、交货期、服务。

**Python 实现**：



```python
criteria_names = ['质量', '价格', '交货期', '服务']
alternative_names = ['S1', 'S2', 'S3']

criteria_matrix = np.array([
    [1, 2, 4, 3],
    [1/2, 1, 3, 2],
    [1/4, 1/3, 1, 1/2],
    [1/3, 1/2, 2, 1]
])

alt_matrices = [
    np.array([[1, 3, 2], [1/3, 1, 1/2], [1/2, 2, 1]]),  # 质量
    np.array([[1, 1/2, 1/3], [2, 1, 1/2], [3, 2, 1]]),  # 价格
    np.array([[1, 1, 2], [1, 1, 2], [1/2, 1/2, 1]]),    # 交货期
    np.array([[1, 2, 3], [1/2, 1, 2], [1/3, 1/2, 1]])   # 服务
]

W = ahp_full(criteria_matrix, alt_matrices, criteria_names, alternative_names)
```



**结果解读**：

- 质量权重最高（0.47），说明企业最重视质量；
- 综合权重 S2 或 S1 最高；
- 可根据结果选择最优供应商。

------

### 案例 3：城市宜居性评价

**问题**：评价 4 个城市的宜居性。准则：经济、环境、社会、基础设施。

**Python 实现**：



```python
import matplotlib.pyplot as plt

criteria_names = ['经济', '环境', '社会', '基础设施']
alternative_names = ['城市A', '城市B', '城市C', '城市D']

criteria_matrix = np.array([
    [1, 3, 2, 4],
    [1/3, 1, 1/2, 2],
    [1/2, 2, 1, 3],
    [1/4, 1/2, 1/3, 1]
])

alt_matrices = [
    np.array([[1, 2, 3, 4], [1/2, 1, 2, 3],
              [1/3, 1/2, 1, 2], [1/4, 1/3, 1/2, 1]]),
    np.array([[1, 1/2, 2, 1/3], [2, 1, 3, 1/2],
              [1/2, 1/3, 1, 1/4], [3, 2, 4, 1]]),
    np.array([[1, 3, 2, 1/2], [1/3, 1, 1/2, 1/4],
              [1/2, 2, 1, 1/3], [2, 4, 3, 1]]),
    np.array([[1, 1, 2, 3], [1, 1, 2, 3],
              [1/2, 1/2, 1, 2], [1/3, 1/3, 1/2, 1]])
]

W = ahp_full(criteria_matrix, alt_matrices, criteria_names, alternative_names)

# 可视化
plt.figure(figsize=(10, 6))
plt.bar(alternative_names, W, color=['steelblue', 'coral', 'green', 'purple'])
plt.xlabel('City')
plt.ylabel('Weight')
plt.title('Urban Livability Evaluation (AHP)')
plt.ylim(0, max(W) * 1.2)
for i, w in enumerate(W):
    plt.(i, w + 0.005, f'{w:.4f}', ha='center')
plt.show()
```



------

### 案例 4：模糊 AHP

**问题**：用三角模糊数处理专家判断的模糊性。

**Python 实现**：



```python
import numpy as np

def fuzzy_ahp(fuzzy_matrix):
    """
    fuzzy_matrix: 三角模糊判断矩阵，元素为 (l, m, u)
    返回：解模糊后的权重
    """
    n = len(fuzzy_matrix)
    
    # 计算每行的模糊几何平均
    r = []
    for i in range(n):
        l_prod = np.prod([fuzzy_matrix[i][j][0] for j in range(n)]) ** (1/n)
        m_prod = np.prod([fuzzy_matrix[i][j][1] for j in range(n)]) ** (1/n)
        u_prod = np.prod([fuzzy_matrix[i][j][2] for j in range(n)]) ** (1/n)
        r.append((l_prod, m_prod, u_prod))
    
    # 计算模糊权重
    l_sum = sum(r[i][0] for i in range(n))
    m_sum = sum(r[i][1] for i in range(n))
    u_sum = sum(r[i][2] for i in range(n))
    
    fuzzy_w = [(r[i][0]/u_sum, r[i][1]/m_sum, r[i][2]/l_sum) for i in range(n)]
    
    # 解模糊（中心值法）
    w = [(l + m + u) / 3 for l, m, u in fuzzy_w]
    w = np.array(w) / sum(w)
    
    return w, fuzzy_w

# 示例：3 个准则的模糊判断矩阵
fuzzy_matrix = [
    [(1, 1, 1), (2, 3, 4), (4, 5, 6)],
    [(1/4, 1/3, 1/2), (1, 1, 1), (2, 3, 4)],
    [(1/6, 1/5, 1/4), (1/4, 1/3, 1/2), (1, 1, 1)]
]

w, fuzzy_w = fuzzy_ahp(fuzzy_matrix)
print(f"模糊权重: {fuzzy_w}")
print(f"解模糊后权重: {w}")
```