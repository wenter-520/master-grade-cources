## 4.1 TOPSIS 的基本原理

### 正理想解与负理想解

**TOPSIS**（Technique for Order Preference by Similarity to Ideal Solution）由 Hwang 和 Yoon 于 1981 年提出。

**核心思想**：最优方案应距离正理想解最近，同时距离负理想解最远。

**正理想解（Positive Ideal Solution, PIS）**：各指标都达到最优值的虚拟方案。


$$
V^+ = \{ v_1^+, v_2^+, \dots, v_m^+ \}
$$


其中


$$
v_j^+ = \max_i v_{ij} \quad (\text{效益型指标})
$$



$$
v_j^+ = \min_i v_{ij} \quad (\text{成本型指标})
$$


**负理想解（Negative Ideal Solution, NIS）**：各指标都达到最差值的虚拟方案。


$$
V^- = \{ v_1^-, v_2^-, \dots, v_m^- \}
$$


其中


$$
v_j^- = \min_i v_{ij} \quad (\text{效益型指标})
$$



$$
v_j^- = \max_i v_{ij} \quad (\text{成本型指标})
$$


**几何意义**：

在 m 维空间中，正理想解和负理想解是两个虚拟点。每个方案是空间中的一个点。TOPSIS 寻找距正理想解最近、距负理想解最远的方案。


$$
\text{最优方案} = \arg\min_i D_i^+ \quad \text{且} \quad \arg\max_i D_i^-
$$


------

### 贴近度

**定义**：方案 i 与正理想解的相对接近程度。


$$
C_i = \frac{D_i^-}{D_i^+ + D_i^-}
$$


其中：

- D~i~^+^：方案 i 到正理想解的距离；
- D~i~^-^：方案 i 到负理想解的距离。

**性质**：

- 0 ≤ C~i~ ≤ 1；
- C~i~ → 1：方案越接近正理想解；
- C~i~ → 0：方案越接近负理想解。

**几何解释**：


$$
C_i = \frac{D_i^-}{D_i^+ + D_i^-}
$$


当 D~i~^+^ = 0 时，C~i~ = 1（完全等于正理想解）；
当 D~i~^-^ = 0 时，C~i~ = 0（完全等于负理想解）。

------

### 排序规则

**排序准则**：按贴近度 C~i~ 从大到小排序。


$$
C_{i_1} \geq C_{i_2} \geq \dots \geq C_{i_n}
$$


方案 i~1~ 最优，i~n~ 最差。

**TOPSIS 的优缺点**：

| 优点               | 缺点                               |
| :----------------- | :--------------------------------- |
| 原理直观，易于理解 | 需预先确定权重                     |
| 计算简单           | 距离度量选择影响结果               |
| 充分利用原始数据   | 可能出现与正负理想解距离相同的情况 |
| 无需假设函数形式   | 未考虑指标间相关性                 |

------

## 4.2 TOPSIS 的计算步骤

### 构建决策矩阵

设有 n 个评价对象，m 个评价指标。

**决策矩阵**：


$$
\mathbf{X} = 
\begin{pmatrix}
x_{11} & x_{12} & \dots & x_{1m} \\
x_{21} & x_{22} & \dots & x_{2m} \\
\vdots & \vdots & \ddots & \vdots \\
x_{n1} & x_{n2} & \dots & x_{nm}
\end{pmatrix}
$$


其中 x~ij~ 为第 i 个对象在第 j 个指标下的原始值。

------

### 标准化处理

**目的**：消除量纲，统一指标方向。

**向量归一化**（TOPSIS 最常用）：


$$
r_{ij} = \frac{x_{ij}}{\sqrt{\sum_{i=1}^n x_{ij}^2}}
$$


**标准化矩阵**：


$$
\mathbf{R} = 
\begin{pmatrix}
r_{11} & r_{12} & \dots & r_{1m} \\
r_{21} & r_{22} & \dots & r_{2m} \\
\vdots & \vdots & \ddots & \vdots \\
r_{n1} & r_{n2} & \dots & r_{nm}
\end{pmatrix}
$$


**注意**：

- 若指标方向不一致，需先做方向一致化；
- 向量归一化后，各指标列向量的模为 1。

**其他标准化方法**：

极差变换：


$$
r_{ij} = \frac{x_{ij} - \min_i x_{ij}}{\max_i x_{ij} - \min_i x_{ij}}
$$


------

### 加权标准化矩阵

**加权标准化矩阵**：


$$
v_{ij} = w_j \cdot r_{ij}
$$


其中 w~j~ 为第 j 个指标的权重，∑w~j~ = 1。

**矩阵形式**：


$$
\mathbf{V} = 
\begin{pmatrix}
w_1 r_{11} & w_2 r_{12} & \dots & w_m r_{1m} \\
w_1 r_{21} & w_2 r_{22} & \dots & w_m r_{2m} \\
\vdots & \vdots & \ddots & \vdots \\
w_1 r_{n1} & w_2 r_{n2} & \dots & w_m r_{nm}
\end{pmatrix}
$$


------

### 确定正负理想解

**正理想解**：


$$
V^+ = \{ v_1^+, v_2^+, \dots, v_m^+ \}
$$


其中


$$
v_j^+ = \max_i v_{ij}
$$


（所有指标已方向一致化为效益型）

**负理想解**：


$$
V^- = \{ v_1^-, v_2^-, \dots, v_m^- \}
$$


其中


$$
v_j^- = \min_i v_{ij}
$$


------

### 计算距离

**到正理想解的距离**（欧氏距离）：


$$
D_i^+ = \sqrt{\sum_{j=1}^m (v_{ij} - v_j^+)^2}
$$


**到负理想解的距离**：


$$
D_i^- = \sqrt{\sum_{j=1}^m (v_{ij} - v_j^-)^2}
$$


**距离矩阵**：


$$
\mathbf{D}^+ = (D_1^+, D_2^+, \dots, D_n^+)^T
$$



$$
\mathbf{D}^- = (D_1^-, D_2^-, \dots, D_n^-)^T
$$


------

### 计算贴近度


$$
C_i = \frac{D_i^-}{D_i^+ + D_i^-}, \quad i = 1, 2, \dots, n
$$


**性质**：

- 0 ≤ C~i~ ≤ 1；
- C~i~ 越大，方案越优。

------

### 排序

按 C~i~ 从大到小排序，得到方案优劣顺序。

**完整 Python 实现**：



```python
import numpy as np
import pandas as pd

def topsis(X, weights, benefit_indicators=None):
    """
    TOPSIS 综合评价
    X: 决策矩阵 (n×m)
    weights: 权重向量 (m,)
    benefit_indicators: 效益型指标索引列表
    """
    n, m = X.shape
    if benefit_indicators is None:
        benefit_indicators = list(range(m))
    
    # 1. 方向一致化（成本型转效益型）
    X_adj = X.copy().astype(float)
    for j in range(m):
        if j not in benefit_indicators:
            X_adj[:, j] = X_adj[:, j].max() - X_adj[:, j] + X_adj[:, j].min()
    
    # 2. 向量归一化
    R = X_adj / np.sqrt((X_adj**2).sum(axis=0))
    
    # 3. 加权标准化矩阵
    V = R * weights
    
    # 4. 正负理想解
    V_plus = V.max(axis=0)
    V_minus = V.min(axis=0)
    
    # 5. 距离
    D_plus = np.sqrt(((V - V_plus)**2).sum(axis=1))
    D_minus = np.sqrt(((V - V_minus)**2).sum(axis=1))
    
    # 6. 贴近度
    C = D_minus / (D_plus + D_minus)
    
    # 7. 排序
    ranking = np.argsort(-C) + 1
    
    return C, ranking, D_plus, D_minus

# 示例
X = np.array([
    [100, 20, 5, 0.8],
    [120, 25, 6, 0.9],
    [90, 18, 4, 0.7],
    [110, 22, 5.5, 0.85]
])
weights = np.array([0.3, 0.25, 0.25, 0.2])
benefit = [0, 2, 3]  # 指标 1 为成本型

C, ranking, D_plus, D_minus = topsis(X, weights, benefit)
print(f"贴近度: {C}")
print(f"排序: {ranking}")
print(f"到正理想解距离: {D_plus}")
print(f"到负理想解距离: {D_minus}")
```



------

## 4.3 距离度量

### 欧氏距离

**定义**：


$$
d(\mathbf{x}, \mathbf{y}) = \sqrt{\sum_{j=1}^m (x_j - y_j)^2}
$$


**TOPSIS 中的应用**：


$$
D_i^+ = \sqrt{\sum_{j=1}^m (v_{ij} - v_j^+)^2}
$$


**特点**：

- 最常用；
- 对各维度等权；
- 受量纲影响（已标准化后无此问题）。

------

### 曼哈顿距离

**定义**（L1 范数）：


$$
d(\mathbf{x}, \mathbf{y}) = \sum_{j=1}^m |x_j - y_j|
$$


**TOPSIS 中的应用**：


$$
D_i^+ = \sum_{j=1}^m |v_{ij} - v_j^+|
$$


**特点**：

- 对异常值更稳健；
- 计算简单；
- 适合高维稀疏数据。

------

### 切比雪夫距离

**定义**（L∞ 范数）：


$$
d(\mathbf{x}, \mathbf{y}) = \max_j |x_j - y_j|
$$


**TOPSIS 中的应用**：


$$
D_i^+ = \max_j |v_{ij} - v_j^+|
$$


**特点**：

- 只考虑最大偏差；
- 对最差指标敏感；
- 适合“短板效应”明显的场景。

------

### 马氏距离

**定义**：考虑指标间相关性的距离。


$$
d(\mathbf{x}, \mathbf{y}) = \sqrt{(\mathbf{x} - \mathbf{y})^T \mathbf{S}^{-1} (\mathbf{x} - \mathbf{y})}
$$


其中 **S** 为协方差矩阵。

**TOPSIS 中的应用**：


$$
D_i^+ = \sqrt{(\mathbf{v}_i - \mathbf{v}^+)^T \mathbf{S}^{-1} (\mathbf{v}_i - \mathbf{v}^+)}
$$


**特点**：

- 消除指标间相关性影响；
- 对量纲不敏感；
- 计算复杂，需估计协方差矩阵。

**四种距离对比**：

| 距离     | 公式            | 特点         | 适用场景 |
| :------- | :-------------- | :----------- | :------- |
| 欧氏     | √Σ(x−y)²        | 常用，等权   | 通用     |
| 曼哈顿   | Σ\|x−y\|        | 稳健         | 高维稀疏 |
| 切比雪夫 | max\|x−y\|      | 关注最大偏差 | 短板效应 |
| 马氏     | √(x−y)ᵀS⁻¹(x−y) | 考虑相关性   | 指标相关 |

**Python 示例**：



```python
from scipy.spatial.distance import cdist

def topsis_with_distance(X, weights, benefit, metric='euclidean'):
    """使用不同距离度量的 TOPSIS"""
    n, m = X.shape
    
    # 方向一致化
    X_adj = X.copy().astype(float)
    for j in range(m):
        if j not in benefit:
            X_adj[:, j] = X_adj[:, j].max() - X_adj[:, j] + X_adj[:, j].min()
    
    # 向量归一化
    R = X_adj / np.sqrt((X_adj**2).sum(axis=0))
    V = R * weights
    
    V_plus = V.max(axis=0).reshape(1, -1)
    V_minus = V.min(axis=0).reshape(1, -1)
    
    # 选择距离度量
    if metric == 'mahalanobis':
        S = np.cov(V.T)
        S_inv = np.linalg.inv(S)
        D_plus = np.sqrt(np.sum((V - V_plus) @ S_inv * (V - V_plus), axis=1))
        D_minus = np.sqrt(np.sum((V - V_minus) @ S_inv * (V - V_minus), axis=1))
    else:
        D_plus = cdist(V, V_plus, metric=metric).flatten()
        D_minus = cdist(V, V_minus, metric=metric).flatten()
    
    C = D_minus / (D_plus + D_minus)
    return C

# 对比不同距离
for metric in ['euclidean', 'cityblock', 'chebyshev', 'mahalanobis']:
    C = topsis_with_distance(X, weights, benefit, metric)
    print(f"{metric}: {C}")
```



------

## 4.4 熵权 TOPSIS

### 熵权法确定权重

**步骤**：

1. 数据标准化；
2. 计算比重；
3. 计算信息熵；
4. 计算差异系数；
5. 确定权重。


$$
w_j = \frac{1 - e_j}{\sum_{k=1}^m (1 - e_k)}
$$


**Python 实现**：



```python
def entropy_weight(X, benefit_indicators=None):
    """熵权法计算权重"""
    n, m = X.shape
    if benefit_indicators is None:
        benefit_indicators = list(range(m))
    
    # 标准化
    X_norm = np.zeros_like(X, dtype=float)
    for j in range(m):
        if j in benefit_indicators:
            X_norm[:, j] = (X[:, j] - X[:, j].min()) / (X[:, j].max() - X[:, j].min())
        else:
            X_norm[:, j] = (X[:, j].max() - X[:, j]) / (X[:, j].max() - X[:, j].min())
    
    X_norm = X_norm + 1e-6
    P = X_norm / X_norm.sum(axis=0)
    E = -np.sum(P * np.log(P), axis=0) / np.log(n)
    D = 1 - E
    W = D / D.sum()
    return W

# 熵权法 + TOPSIS
weights_entropy = entropy_weight(X, benefit)
C, ranking, _, _ = topsis(X, weights_entropy, benefit)
print(f"熵权: {weights_entropy}")
print(f"熵权 TOPSIS 贴近度: {C}")
print(f"排序: {ranking}")
```



------

### TOPSIS 排序

熵权 TOPSIS 将熵权法的客观权重与 TOPSIS 的排序能力结合。

**流程**：



```tex
原始数据 → 熵权法确定权重 → TOPSIS 计算贴近度 → 排序
```



**优点**：

- 权重客观；
- 排序直观；
- 充分利用数据信息。

**Python 完整实现**：



```python
def entropy_topsis(X, benefit_indicators):
    """熵权 TOPSIS"""
    # 熵权
    W = entropy_weight(X, benefit_indicators)
    # TOPSIS
    C, ranking, D_plus, D_minus = topsis(X, W, benefit_indicators)
    return C, ranking, W, D_plus, D_minus

C, ranking, W, D_plus, D_minus = entropy_topsis(X, benefit)
print(f"权重: {W}")
print(f"贴近度: {C}")
print(f"排序: {ranking}")
```



------

### 组合评价

**组合评价**：将熵权 TOPSIS 与其他方法组合，提高稳健性。

**方法一：权重组合**

将熵权与其他客观权重组合：


$$
w_j = \alpha w_j^{\text{entropy}} + (1-\alpha) w_j^{\text{other}}
$$


**方法二：结果组合**

将 TOPSIS 与其他评价方法的结果组合（Borda 法、平均值法等）。

**方法三：距离组合**

使用多种距离度量，综合贴近度。

------

## 4.5 灰色 TOPSIS

### 灰色关联度

**灰色关联度**衡量比较序列与参考序列的几何相似程度。

**步骤**：

1. 确定参考序列（正理想解）；
2. 计算差序列：


$$
\Delta_{ij} = |v_{ij} - v_j^+|
$$


1. 计算关联系数：


$$
\xi_{ij} = \frac{\min_i \min_j \Delta_{ij} + \rho \max_i \max_j \Delta_{ij}}{\Delta_{ij} + \rho \max_i \max_j \Delta_{ij}}
$$


其中 ρ ∈ (0, 1) 为分辨系数，通常取 0.5。

1. 计算灰色关联度：


$$
r_i = \frac{1}{m} \sum_{j=1}^m \xi_{ij}
$$


**含义**：r~i~ 越大，方案 i 与正理想解越相似。

------

### 灰色贴近度

**灰色贴近度**：结合灰色关联度和 TOPSIS 距离。

**定义**：


$$
C_i^{\text{grey}} = \frac{r_i^-}{r_i^+ + r_i^-}
$$


其中：

- r~i~^+^：方案 i 与正理想解的灰色关联度；
- r~i~^-^：方案 i 与负理想解的灰色关联度。

**计算步骤**：

1. 计算方案 i 与正理想解的关联系数：


$$
\xi_{ij}^+ = \frac{\min_i \min_j |v_{ij} - v_j^+| + \rho \max_i \max_j |v_{ij} - v_j^+|}{|v_{ij} - v_j^+| + \rho \max_i \max_j |v_{ij} - v_j^+|}
$$


1. 计算方案 i 与负理想解的关联系数：


$$
\xi_{ij}^- = \frac{\min_i \min_j |v_{ij} - v_j^-| + \rho \max_i \max_j |v_{ij} - v_j^-|}{|v_{ij} - v_j^-| + \rho \max_i \max_j |v_{ij} - v_j^-|}
$$


1. 计算关联度：


$$
r_i^+ = \frac{1}{m} \sum_{j=1}^m \xi_{ij}^+
$$



$$
r_i^- = \frac{1}{m} \sum_{j=1}^m \xi_{ij}^-
$$


1. 计算灰色贴近度：


$$
C_i^{\text{grey}} = \frac{r_i^-}{r_i^+ + r_i^-}
$$


**Python 实现**：



```python
def grey_topsis(X, weights, benefit, rho=0.5):
    """灰色 TOPSIS"""
    n, m = X.shape
    
    # 方向一致化
    X_adj = X.copy().astype(float)
    for j in range(m):
        if j not in benefit:
            X_adj[:, j] = X_adj[:, j].max() - X_adj[:, j] + X_adj[:, j].min()
    
    # 向量归一化
    R = X_adj / np.sqrt((X_adj**2).sum(axis=0))
    V = R * weights
    
    V_plus = V.max(axis=0)
    V_minus = V.min(axis=0)
    
    # 与正理想解的关联系数
    Delta_plus = np.abs(V - V_plus)
    min_dp = Delta_plus.min()
    max_dp = Delta_plus.max()
    xi_plus = (min_dp + rho * max_dp) / (Delta_plus + rho * max_dp)
    r_plus = xi_plus.mean(axis=1)
    
    # 与负理想解的关联系数
    Delta_minus = np.abs(V - V_minus)
    min_dm = Delta_minus.min()
    max_dm = Delta_minus.max()
    xi_minus = (min_dm + rho * max_dm) / (Delta_minus + rho * max_dm)
    r_minus = xi_minus.mean(axis=1)
    
    # 灰色贴近度
    C = r_minus / (r_plus + r_minus)
    
    return C, r_plus, r_minus

C_grey, r_plus, r_minus = grey_topsis(X, weights_entropy, benefit)
print(f"灰色贴近度: {C_grey}")
print(f"排序: {np.argsort(-C_grey) + 1}")
```



------

## 4.6 TOPSIS 的改进

### 垂直距离 TOPSIS

**问题**：传统 TOPSIS 使用欧氏距离，当正负理想解连线不与方案点垂直时，可能产生误判。

**改进**：使用方案点到正负理想解连线的垂直距离。

**正负理想解连线方向**：


$$
\mathbf{d} = \mathbf{V}^+ - \mathbf{V}^-
$$


**方案点到连线的投影距离**：


$$
D_i^{\text{proj}} = \frac{(\mathbf{v}_i - \mathbf{V}^-) \cdot \mathbf{d}}{\|\mathbf{d}\|}
$$


**垂直距离**：


$$
D_i^{\perp} = \|\mathbf{v}_i - \mathbf{V}^- - D_i^{\text{proj}} \frac{\mathbf{d}}{\|\mathbf{d}\|}\|
$$


**改进的贴近度**：


$$
C_i = \frac{D_i^{\text{proj}}}{\|\mathbf{d}\|}
$$


**优点**：避免了传统 TOPSIS 的“对称问题”。

------

### 正交投影 TOPSIS

**思想**：用方案点在正负理想解连线上的正交投影作为评价依据。

**投影值**：


$$
P_i = \frac{(\mathbf{v}_i - \mathbf{V}^-) \cdot (\mathbf{V}^+ - \mathbf{V}^-)}{\|\mathbf{V}^+ - \mathbf{V}^-\|}
$$


**贴近度**：


$$
C_i = \frac{P_i}{\|\mathbf{V}^+ - \mathbf{V}^-\|}
$$


**性质**：C~i~ ∈ [0, 1]，越大越好。

------

### 动态 TOPSIS

**问题**：处理面板数据（时间序列 + 截面数据）。

**方法**：

**方法一：时间加权**

对各时间点的贴近度加权：


$$
C_i = \sum_{t=1}^T \lambda_t C_i^{(t)}
$$


其中 λ~t~ 为时间权重（通常近期权重更大）。

**方法二：动态决策矩阵**

将不同时间点的数据整合为一个大的决策矩阵。

**方法三：灰色动态 TOPSIS**

结合灰色预测和 TOPSIS，对未来的方案进行评价。

**时间权重确定**：


$$
\lambda_t = \frac{t}{\sum_{s=1}^T s}
$$


（线性递增）

或


$$
\lambda_t = \frac{e^{\alpha t}}{\sum_{s=1}^T e^{\alpha s}}
$$


（指数递增）

**Python 示例**：



```python
def dynamic_topsis(X_list, weights, benefit, time_weights=None):
    """
    动态 TOPSIS
    X_list: 各时间点的决策矩阵列表
    """
    T = len(X_list)
    if time_weights is None:
        time_weights = np.arange(1, T+1) / sum(range(1, T+1))
    
    n = X_list[0].shape[0]
    C_total = np.zeros(n)
    
    for t, X_t in enumerate(X_list):
        C_t, _, _, _ = topsis(X_t, weights, benefit)
        C_total += time_weights[t] * C_t
    
    return C_total

# 示例：3 个时间点
X1 = np.array([[100, 20, 5], [120, 25, 6], [90, 18, 4]])
X2 = np.array([[110, 22, 5.5], [130, 27, 6.5], [95, 20, 4.5]])
X3 = np.array([[115, 23, 5.8], [135, 28, 6.8], [100, 21, 4.8]])

C_dynamic = dynamic_topsis([X1, X2, X3], weights[:3], [0, 2])
print(f"动态贴近度: {C_dynamic}")
```



------

## 4.7 TOPSIS 建模案例

### 案例 1：供应商选择

**问题**：某企业选择最优供应商，4 个候选供应商 S1—S4，5 个指标：价格、质量、交货期、服务、信誉。

**数据**：

| 供应商 | 价格(元) | 质量(分) | 交货期(天) | 服务(分) | 信誉(分) |
| :----- | :------- | :------- | :--------- | :------- | :------- |
| S1     | 100      | 85       | 10         | 80       | 90       |
| S2     | 120      | 90       | 8          | 85       | 85       |
| S3     | 90       | 80       | 12         | 75       | 95       |
| S4     | 110      | 88       | 9          | 88       | 82       |

**指标类型**：价格、交货期为成本型；质量、服务、信誉为效益型。

**Python 实现**：



```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 数据
X = np.array([
    [100, 85, 10, 80, 90],
    [120, 90, 8, 85, 85],
    [90, 80, 12, 75, 95],
    [110, 88, 9, 88, 82]
])
suppliers = ['S1', 'S2', 'S3', 'S4']
indicators = ['价格', '质量', '交货期', '服务', '信誉']
benefit = [1, 3, 4]  # 质量、服务、信誉为效益型

# 熵权法
W = entropy_weight(X, benefit)
print("熵权法权重:")
for name, w in zip(indicators, W):
    print(f"  {name}: {w:.4f}")

# TOPSIS
C, ranking, D_plus, D_minus = topsis(X, W, benefit)

print("\nTOPSIS 结果:")
print(f"{'供应商':<8} {'D+':<8} {'D-':<8} {'贴近度':<10} {'排名':<6}")
for i in range(len(suppliers)):
    rank = list(ranking).index(i+1) + 1
    print(f"{suppliers[i]:<8} {D_plus[i]:<8.4f} {D_minus[i]:<8.4f} {C[i]:<10.4f} {rank:<6}")

# 可视化
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# 权重
axes[0].bar(indicators, W, color='steelblue')
axes[0].set_ylabel('Weight')
axes[0].set_title('Entropy Weight')
for i, w in enumerate(W):
    axes[0].(i, w + 0.005, f'{w:.3f}', ha='center')

# 贴近度
colors = ['gold' if i == ranking[0]-1 else 'steelblue' for i in range(len(suppliers))]
axes[1].bar(suppliers, C, color=colors)
axes[1].set_ylabel('Closeness Coefficient')
axes[1].set_title('TOPSIS Evaluation')
for i, c in enumerate(C):
    axes[1].(i, c + 0.005, f'{c:.3f}', ha='center')

plt.tight_layout()
plt.show()
```



**结果解读**：

- 熵权法根据数据差异客观赋权；
- S2 或 S4 综合得分最高；
- 结果可用于供应商选择决策。

------

### 案例 2：城市竞争力评价

**问题**：评价 8 个城市的综合竞争力，指标包括经济、科技、教育、环境、基础设施等。

**Python 实现**：



```python
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)
cities = [f'City {i+1}' for i in range(8)]
indicators = ['GDP', 'R&D', 'Education', 'Environment', 'Infrastructure',
              'Healthcare', 'Culture', 'Safety']

# 模拟数据
X = np.random.rand(8, 8) * 100

# 假设所有指标为效益型，除 Environment 为成本型（污染指数）
benefit = [0, 1, 2, 4, 5, 6, 7]

# 熵权 TOPSIS
W = entropy_weight(X, benefit)
C, ranking, _, _ = topsis(X, W, benefit)

print("城市竞争力排名:")
for rank, i in enumerate(ranking, 1):
    print(f"  {rank}. {cities[i-1]}: {C[i-1]:.4f}")

# 可视化
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

axes[0].barh(indicators, W, color='steelblue')
axes[0].set_xlabel('Weight')
axes[0].set_title('Indicator Weights (Entropy)')

sorted_idx = np.argsort(-C)
axes[1].barh([cities[i] for i in sorted_idx],
             [C[i] for i in sorted_idx], color='coral')
axes[1].set_xlabel('Closeness Coefficient')
axes[1].set_title('City Competitiveness Ranking')

plt.tight_layout()
plt.show()
```



------

### 案例 3：熵权 TOPSIS vs 灰色 TOPSIS 对比

**问题**：对比传统 TOPSIS 和灰色 TOPSIS 的结果。

**Python 实现**：



```python
# 传统 TOPSIS
C_topsis, ranking_topsis, _, _ = topsis(X, W, benefit)

# 灰色 TOPSIS
C_grey, r_plus, r_minus = grey_topsis(X, W, benefit)
ranking_grey = np.argsort(-C_grey) + 1

print("传统 TOPSIS vs 灰色 TOPSIS:")
print(f"{'城市':<10} {'传统':<10} {'灰色':<10}")
for i in range(len(cities)):
    print(f"{cities[i]:<10} {C_topsis[i]:<10.4f} {C_grey[i]:<10.4f}")

print(f"\n传统排序: {ranking_topsis}")
print(f"灰色排序: {ranking_grey}")

# 可视化对比
fig, ax = plt.subplots(figsize=(10, 6))
x = np.arange(len(cities))
width = 0.35

ax.bar(x - width/2, C_topsis, width, label='Traditional TOPSIS', color='steelblue')
ax.bar(x + width/2, C_grey, width, label='Grey TOPSIS', color='coral')
ax.set_xticks(x)
ax.set_xticklabels(cities, rotation=45)
ax.set_ylabel('Closeness')
ax.set_title('TOPSIS vs Grey TOPSIS')
ax.legend()
plt.tight_layout()
plt.show()
```



------

### 案例 4：动态 TOPSIS 评价

**问题**：评价 5 个城市在 2019—2023 年的综合发展水平变化。

**Python 实现**：



```python 
import numpy as np
import matplotlib.pyplot as plt

# 模拟 5 年数据
np.random.seed(42)
years = [2019, 2020, 2021, 2022, 2023]
n_cities = 5
n_indicators = 6
cities = [f'City {i+1}' for i in range(n_cities)]

X_years = []
for year in years:
    X_years.append(np.random.rand(n_cities, n_indicators) * 100)

# 假设所有指标为效益型
benefit = list(range(n_indicators))

# 时间权重（近期权重更大）
time_weights = np.array([0.1, 0.15, 0.2, 0.25, 0.3])

# 各年 TOPSIS
C_by_year = np.zeros((n_cities, len(years)))
for t, X_t in enumerate(X_years):
    W_t = entropy_weight(X_t, benefit)
    C_t, _, _, _ = topsis(X_t, W_t, benefit)
    C_by_year[:, t] = C_t

# 动态综合
C_dynamic = C_by_year @ time_weights

print("各城市动态综合得分:")
for i, city in enumerate(cities):
    print(f"  {city}: {C_dynamic[i]:.4f}")

print(f"\n最终排序: {np.argsort(-C_dynamic) + 1}")

# 可视化
plt.figure(figsize=(12, 6))
for i, city in enumerate(cities):
    plt.plot(years, C_by_year[i], 'o-', label=city)
plt.xlabel('Year')
plt.ylabel('Closeness Coefficient')
plt.title('Dynamic TOPSIS Evaluation')
plt.legend()
plt.grid(True)
plt.show()
```