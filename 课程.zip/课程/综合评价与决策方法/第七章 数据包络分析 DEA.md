## 7.1 DEA 的基本原理

### 投入与产出

**投入**：决策单元消耗的资源，记作


$$
x_{ij}, \quad i = 1, 2, \dots, m, \quad j = 1, 2, \dots, n
$$


其中 m 为投入指标数，n 为决策单元数。

**产出**：决策单元获得的成果，记作


$$
y_{rj}, \quad r = 1, 2, \dots, s, \quad j = 1, 2, \dots, n
$$


其中 s 为产出指标数。

**投入产出矩阵**：

投入矩阵：


$$
\mathbf{X} = 
\begin{pmatrix}
x_{11} & x_{12} & \dots & x_{1n} \\
x_{21} & x_{22} & \dots & x_{2n} \\
\vdots & \vdots & \ddots & \vdots \\
x_{m1} & x_{m2} & \dots & x_{mn}
\end{pmatrix}_{m \times n}
$$


产出矩阵：


$$
\mathbf{Y} = 
\begin{pmatrix}
y_{11} & y_{12} & \dots & y_{1n} \\
y_{21} & y_{22} & \dots & y_{2n} \\
\vdots & \vdots & \ddots & \vdots \\
y_{s1} & y_{s2} & \dots & y_{sn}
\end{pmatrix}_{s \times n}
$$


**基本要求**：

- 投入越小越好；
- 产出越大越好；
- 投入与产出均为非负数据。

------

### 决策单元 DMU

**决策单元**（Decision Making Unit, DMU）：具有相同投入产出结构的被评价对象。

记第 j 个 DMU 为 DMU~j~，其投入向量和产出向量分别为


$$
\mathbf{x}_j = (x_{1j}, x_{2j}, \dots, x_{mj})^T
$$



$$
\mathbf{y}_j = (y_{1j}, y_{2j}, \dots, y_{sj})^T
$$


**DMU 的同质性**：

- 目标相同；
- 外部环境相似；
- 投入产出指标相同；
- 量纲可不同，DEA 自动处理。

------

### 效率前沿面

**效率前沿面**：由 DEA 有效的 DMU 构成的生产可能集边界。

**生产可能集**：


$$
T = \left\{ (\mathbf{x}, \mathbf{y}) \mid \mathbf{x} \geq \sum_{j=1}^n \lambda_j \mathbf{x}_j, \ \mathbf{y} \leq \sum_{j=1}^n \lambda_j \mathbf{y}_j, \ \lambda_j \geq 0 \right\}
$$


**效率前沿面**：生产可能集的有效边界。

位于前沿面上的 DMU 效率值为 1，称为 DEA 有效；不在前沿面上的 DMU 效率值小于 1。

------

### 技术效率

**技术效率**：在给定投入下获得最大产出的能力，或在给定产出下使用最小投入的能力。

**输入导向技术效率**：


$$
\theta^* = \min \theta
$$


使得在投入缩小为原来的 θ 倍时，仍能保持产出不变。

**输出导向技术效率**：


$$
\phi^* = \max \phi
$$


使得在投入不变时，产出可扩大为原来的 φ 倍。

**效率值**：

- θ^*^ = 1：DEA 有效；
- θ^*^ < 1：DEA 无效，存在投入冗余或产出不足。

------

## 7.2 CCR 模型

### 分式规划

CCR 模型由 Charnes、Cooper 和 Rhodes 于 1978 年提出，假设规模报酬不变（CRS）。

对第 j~0~ 个 DMU，分式规划为：


$$
\begin{aligned}
\max \quad & h_{j_0} = \frac{\sum_{r=1}^s u_r y_{rj_0}}{\sum_{i=1}^m v_i x_{ij_0}} \\
\text{s.t.} \quad & \frac{\sum_{r=1}^s u_r y_{rj}}{\sum_{i=1}^m v_i x_{ij}} \leq 1, \quad j = 1, 2, \dots, n \\
& u_r \geq 0, \quad r = 1, 2, \dots, s \\
& v_i \geq 0, \quad i = 1, 2, \dots, m
\end{aligned}
$$


其中 u~r~ 为第 r 个产出的权重，v~i~ 为第 i 个投入的权重。

------

### 线性规划形式

令


$$
t = \frac{1}{\sum_{i=1}^m v_i x_{ij_0}}
$$



$$
\mu_r = t u_r, \quad \nu_i = t v_i
$$


则分式规划转化为线性规划：


$$
\begin{aligned}
\max \quad & \sum_{r=1}^s \mu_r y_{rj_0} \\
\text{s.t.} \quad & \sum_{i=1}^m \nu_i x_{ij_0} = 1 \\
& \sum_{r=1}^s \mu_r y_{rj} - \sum_{i=1}^m \nu_i x_{ij} \leq 0, \quad j = 1, 2, \dots, n \\
& \mu_r \geq 0, \quad \nu_i \geq 0
\end{aligned}
$$


------

### 对偶形式

对偶模型（输入导向）：


$$
\begin{aligned}
\min \quad & \theta \\
\text{s.t.} \quad & \sum_{j=1}^n \lambda_j x_{ij} \leq \theta x_{ij_0}, \quad i = 1, 2, \dots, m \\
& \sum_{j=1}^n \lambda_j y_{rj} \geq y_{rj_0}, \quad r = 1, 2, \dots, s \\
& \lambda_j \geq 0, \quad j = 1, 2, \dots, n
\end{aligned}
$$


**含义**：

- θ 为第 j~0~ 个 DMU 的效率值；
- λ~j~ 为参考权重；
- θ^*^ = 1 时 DEA 有效。

**引入松弛变量**：


$$
\begin{aligned}
\min \quad & \theta - \varepsilon \left( \sum_{i=1}^m s_i^- + \sum_{r=1}^s s_r^+ \right) \\
\text{s.t.} \quad & \sum_{j=1}^n \lambda_j x_{ij} + s_i^- = \theta x_{ij_0}, \quad i = 1, 2, \dots, m \\
& \sum_{j=1}^n \lambda_j y_{rj} - s_r^+ = y_{rj_0}, \quad r = 1, 2, \dots, s \\
& \lambda_j \geq 0, \quad s_i^- \geq 0, \quad s_r^+ \geq 0
\end{aligned}
$$


其中 ε 为阿基米德无穷小量。

------

### 效率值

**DEA 有效**：

- θ^*^ = 1 且所有松弛变量为 0；
- DMU 位于效率前沿面上。

**DEA 弱有效**：

- θ^*^ = 1 但存在非零松弛变量。

**DEA 无效**：

- θ^*^ < 1；
- 存在投入冗余或产出不足。

**投入冗余**：


$$
\Delta x_i = x_{ij_0} - \theta^* x_{ij_0} - s_i^{-*}
$$


**产出不足**：


$$
\Delta y_r = s_r^{+*}
$$


**Python 示例（CCR 输入导向）**：



```python
import numpy as np
from scipy.optimize import linprog

def dea_ccr(X, Y):
    """
    CCR 模型（输入导向，CRS）
    X: 投入矩阵 (m×n)
    Y: 产出矩阵 (s×n)
    返回: 各 DMU 的效率值
    """
    m, n = X.shape
    s = Y.shape[0]
    efficiencies = np.zeros(n)
    
    for k in range(n):
        # 决策变量: [lambda_1..lambda_n, theta]
        c = np.zeros(n + 1)
        c[-1] = 1  # 最小化 theta
        
        # 不等式约束: X lambda - theta x_k <= 0
        A_ub = np.zeros((m + s, n + 1))
        b_ub = np.zeros(m + s)
        
        # 投入约束
        for i in range(m):
            A_ub[i, :n] = X[i, :]
            A_ub[i, n] = -X[i, k]
            b_ub[i] = 0
        
        # 产出约束: -Y lambda <= -y_k
        for r in range(s):
            A_ub[m + r, :n] = -Y[r, :]
            b_ub[m + r] = -Y[r, k]
        
        bounds = [(0, None)] * n + [(0, None)]
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
        
        if res.success:
            efficiencies[k] = res.x[-1]
        else:
            efficiencies[k] = np.nan
    
    return efficiencies

# 示例：5 个 DMU，2 投入，1 产出
X = np.array([
    [10, 12, 8, 15, 9],
    [5, 6, 4, 8, 5]
], dtype=float)

Y = np.array([
    [100, 110, 80, 130, 90]
], dtype=float)

eff = dea_ccr(X, Y)
print(f"CCR 效率值: {eff}")
```



------

## 7.3 BCC 模型

### 规模报酬可变

BCC 模型由 Banker、Charnes 和 Cooper 于 1984 年提出，假设规模报酬可变（VRS）。

在 CCR 对偶模型基础上增加约束：


$$
\sum_{j=1}^n \lambda_j = 1
$$


BCC 对偶模型：


$$
\begin{aligned}
\min \quad & \theta \\
\text{s.t.} \quad & \sum_{j=1}^n \lambda_j x_{ij} \leq \theta x_{ij_0}, \quad i = 1, 2, \dots, m \\
& \sum_{j=1}^n \lambda_j y_{rj} \geq y_{rj_0}, \quad r = 1, 2, \dots, s \\
& \sum_{j=1}^n \lambda_j = 1 \\
& \lambda_j \geq 0, \quad j = 1, 2, \dots, n
\end{aligned}
$$


------

### 纯技术效率

**纯技术效率**（Pure Technical Efficiency, PTE）：BCC 模型计算的效率值。


$$
\text{PTE} = \theta_{\text{BCC}}^*
$$


**含义**：剔除规模因素后的技术效率，反映管理水平和资源配置能力。

------

### 规模效率

**规模效率**（Scale Efficiency, SE）：


$$
\text{SE} = \frac{\theta_{\text{CCR}}^*}{\theta_{\text{BCC}}^*}
$$


**性质**：

- SE = 1：规模有效，处于最优规模；
- SE < 1：规模无效，存在规模报酬递增或递减。

**规模报酬状态**：

- 若 ∑λ~j~^*^ = 1：规模报酬不变；
- 若 ∑λ~j~^*^ < 1：规模报酬递增；
- 若 ∑λ~j~^*^ > 1：规模报酬递减。

**Python 示例（BCC）**：



```python
def dea_bcc(X, Y):
    """
    BCC 模型（输入导向，VRS）
    """
    m, n = X.shape
    s = Y.shape[0]
    efficiencies = np.zeros(n)
    lambdas_sum = np.zeros(n)
    
    for k in range(n):
        c = np.zeros(n + 1)
        c[-1] = 1
        
        A_ub = np.zeros((m + s, n + 1))
        b_ub = np.zeros(m + s)
        
        for i in range(m):
            A_ub[i, :n] = X[i, :]
            A_ub[i, n] = -X[i, k]
            b_ub[i] = 0
        
        for r in range(s):
            A_ub[m + r, :n] = -Y[r, :]
            b_ub[m + r] = -Y[r, k]
        
        # 增加约束 sum(lambda) = 1
        A_eq = np.zeros((1, n + 1))
        A_eq[0, :n] = 1
        b_eq = np.array([1])
        
        bounds = [(0, None)] * n + [(0, None)]
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                      bounds=bounds, method='highs')
        
        if res.success:
            efficiencies[k] = res.x[-1]
            lambdas_sum[k] = res.x[:n].sum()
        else:
            efficiencies[k] = np.nan
    
    return efficiencies, lambdas_sum

eff_ccr = dea_ccr(X, Y)
eff_bcc, lambda_sum = dea_bcc(X, Y)
scale_eff = eff_ccr / eff_bcc

print(f"CCR 效率: {eff_ccr}")
print(f"BCC 效率: {eff_bcc}")
print(f"规模效率: {scale_eff}")
print(f"规模报酬状态: {['递增' if s < 1 else '递减' if s > 1 else '不变' for s in lambda_sum]}")
```



------

## 7.4 DEA 的扩展模型

### 超效率 DEA

**问题**：传统 DEA 中多个 DMU 效率值为 1，无法进一步排序。

**超效率 DEA**：在评价 DMU~k~ 时，将其从参考集中排除。

**超效率 CCR 对偶模型**：


$$
\begin{aligned}
\min \quad & \theta \\
\text{s.t.} \quad & \sum_{j \neq k} \lambda_j x_{ij} \leq \theta x_{ik}, \quad i = 1, 2, \dots, m \\
& \sum_{j \neq k} \lambda_j y_{rj} \geq y_{rk}, \quad r = 1, 2, \dots, s \\
& \lambda_j \geq 0, \quad j \neq k
\end{aligned}
$$


**效率值**：

- θ^*^ ≥ 1：超效率值；
- θ^*^ 越大，DMU 越优；
- 可对 DEA 有效的 DMU 进一步排序。

**Python 示例**：



```python
def dea_super_ccr(X, Y):
    """超效率 CCR 模型"""
    m, n = X.shape
    s = Y.shape[0]
    efficiencies = np.zeros(n)
    
    for k in range(n):
        # 排除第 k 个 DMU
        indices = [j for j in range(n) if j != k]
        n_eff = len(indices)
        
        c = np.zeros(n_eff + 1)
        c[-1] = 1
        
        A_ub = np.zeros((m + s, n_eff + 1))
        b_ub = np.zeros(m + s)
        
        for i in range(m):
            A_ub[i, :n_eff] = X[i, indices]
            A_ub[i, n_eff] = -X[i, k]
            b_ub[i] = 0
        
        for r in range(s):
            A_ub[m + r, :n_eff] = -Y[r, indices]
            b_ub[m + r] = -Y[r, k]
        
        bounds = [(0, None)] * n_eff + [(0, None)]
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
        
        if res.success:
            efficiencies[k] = res.x[-1]
        else:
            efficiencies[k] = np.nan
    
    return efficiencies

super_eff = dea_super_ccr(X, Y)
print(f"超效率 CCR: {super_eff}")
```



------

### Malmquist 指数

**目的**：衡量跨期生产率变化。

**Malmquist 生产率指数**：


$$
M_0^{t, t+1} = \sqrt{
\frac{D_0^t(\mathbf{x}^{t+1}, \mathbf{y}^{t+1})}{D_0^t(\mathbf{x}^t, \mathbf{y}^t)}
\times
\frac{D_0^{t+1}(\mathbf{x}^{t+1}, \mathbf{y}^{t+1})}{D_0^{t+1}(\mathbf{x}^t, \mathbf{y}^t)}
}
$$


其中 D~0~^t^(·) 为第 t 期的距离函数。

**分解**：


$$
M_0^{t, t+1} = \text{TEC} \times \text{TC}
$$


其中：

- TEC：技术效率变化；
- TC：技术进步。

**进一步分解**：


$$
\text{TEC} = \text{PTEC} \times \text{SEC}
$$


其中 PTEC 为纯技术效率变化，SEC 为规模效率变化。

**判断**：

- M > 1：生产率提高；
- M = 1：生产率不变；
- M < 1：生产率下降。

------

### 网络 DEA

**思想**：将 DMU 的内部过程分解为多个子阶段。

**两阶段网络 DEA**：

第一阶段：投入 X → 中间产品 Z；
第二阶段：中间产品 Z → 产出 Y。

**模型**：


$$
\begin{aligned}
\min \quad & \theta \\
\text{s.t.} \quad & \sum_{j=1}^n \lambda_j x_{ij} \leq \theta x_{ij_0} \\
& \sum_{j=1}^n \lambda_j z_{pj} \geq z_{pj_0} \\
& \sum_{j=1}^n \mu_j z_{pj} \leq z_{pj_0} \\
& \sum_{j=1}^n \mu_j y_{rj} \geq y_{rj_0} \\
& \lambda_j, \mu_j \geq 0
\end{aligned}
$$


**应用**：银行（存款→贷款→收益）、高校（投入→科研→教学）。

------

### 随机 DEA

**思想**：考虑随机误差，处理不确定性。

**机会约束 DEA**：


$$
\begin{aligned}
\min \quad & \theta \\
\text{s.t.} \quad & P\left( \sum_{j=1}^n \lambda_j x_{ij} \leq \theta x_{ij_0} \right) \geq 1 - \alpha \\
& P\left( \sum_{j=1}^n \lambda_j y_{rj} \geq y_{rj_0} \right) \geq 1 - \alpha \\
& \lambda_j \geq 0
\end{aligned}
$$


**随机前沿分析（SFA）+ DEA**：先剔除随机误差，再用 DEA 评估。

------

## 7.5 DEA 的投入产出指标选取

### 指标选取原则

**相关性**：投入与产出之间存在逻辑关联。

**全面性**：覆盖 DMU 的主要投入和产出。

**独立性**：投入指标之间、产出指标之间尽量独立。

**可操作性**：数据可获取、可量化。

**非负性**：所有投入产出数据非负。

------

### 指标数量限制

**经验法则**：


$$
m + s \leq \frac{n}{3}
$$


或


$$
m + s \leq \frac{n}{2}
$$


其中 m 为投入指标数，s 为产出指标数，n 为 DMU 数。

**原因**：指标过多会导致大量 DMU 效率值为 1，失去区分能力。

**处理策略**：

- 减少指标；
- 增加 DMU；
- 使用主成分分析降维；
- 使用超效率 DEA。

------

### 数据要求

- 数据非负；
- 数据完整，缺失值需处理；
- 数据可比，统计口径一致；
- DMU 数量足够（通常 ≥ 3(m+s)）；
- 极端值需检查。

------

## 7.6 DEA 建模案例

### 案例 1：银行效率评价

**问题**：评价 6 家银行的效率，投入为员工数、固定资产，产出为存款、贷款、利润。

**数据**：

| 银行 | 员工数 | 固定资产 | 存款  | 贷款  | 利润 |
| :--- | :----- | :------- | :---- | :---- | :--- |
| A    | 1000   | 5000     | 20000 | 15000 | 800  |
| B    | 1200   | 6000     | 25000 | 18000 | 1000 |
| C    | 800    | 4000     | 15000 | 12000 | 600  |
| D    | 1500   | 7000     | 30000 | 22000 | 1200 |
| E    | 900    | 4500     | 18000 | 13000 | 700  |
| F    | 1100   | 5500     | 22000 | 16000 | 900  |

**Python 实现**：



```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 数据
banks = ['A', 'B', 'C', 'D', 'E', 'F']
X = np.array([
    [1000, 1200, 800, 1500, 900, 1100],
    [5000, 6000, 4000, 7000, 4500, 5500]
], dtype=float)

Y = np.array([
    [20000, 25000, 15000, 30000, 18000, 22000],
    [15000, 18000, 12000, 22000, 13000, 16000],
    [800, 1000, 600, 1200, 700, 900]
], dtype=float)

# CCR 效率
eff_ccr = dea_ccr(X, Y)

# BCC 效率
eff_bcc, lambda_sum = dea_bcc(X, Y)

# 规模效率
scale_eff = eff_ccr / eff_bcc

# 超效率
super_eff = dea_super_ccr(X, Y)

# 汇总
df = pd.DataFrame({
    '银行': banks,
    'CCR效率': eff_ccr,
    'BCC效率': eff_bcc,
    '规模效率': scale_eff,
    '超效率': super_eff,
    '规模报酬': ['递增' if s < 1 else '递减' if s > 1 else '不变' for s in lambda_sum]
})

print(df.to_string(index=False))

# 可视化
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

x = np.arange(len(banks))
width = 0.25

axes[0].bar(x - width, eff_ccr, width, label='CCR')
axes[0].bar(x, eff_bcc, width, label='BCC')
axes[0].bar(x + width, scale_eff, width, label='Scale')
axes[0].set_xticks(x)
axes[0].set_xticklabels(banks)
axes[0].set_ylabel('Efficiency')
axes[0].set_title('DEA Efficiency')
axes[0].legend()

axes[1].bar(banks, super_eff, color='coral')
axes[1].set_ylabel('Super Efficiency')
axes[1].set_title('Super Efficiency DEA')
for i, v in enumerate(super_eff):
    axes[1].(i, v + 0.01, f'{v:.3f}', ha='center')

plt.tight_layout()
plt.show()
```



**结果解读**：

- CCR 效率 = 1 的银行为 DEA 有效；
- BCC 效率剔除规模因素；
- 规模效率 < 1 说明规模无效；
- 超效率可对有效银行进一步排序。

------

### 案例 2：城市效率评价

**问题**：评价 10 个城市的运行效率，投入为固定资产投资、从业人员数，产出为 GDP、财政收入、居民收入。

**Python 实现**：



```python
import numpy as np
import pandas as pd

np.random.seed(42)
n_cities = 10
cities = [f'City {i+1}' for i in range(n_cities)]

# 模拟数据
X = np.random.rand(2, n_cities) * 100 + 50  # 投入
Y = np.random.rand(3, n_cities) * 200 + 100  # 产出

# CCR
eff_ccr = dea_ccr(X, Y)
# BCC
eff_bcc, lambda_sum = dea_bcc(X, Y)
# 规模效率
scale_eff = eff_ccr / eff_bcc
# 超效率
super_eff = dea_super_ccr(X, Y)

df = pd.DataFrame({
    '城市': cities,
    'CCR': eff_ccr,
    'BCC': eff_bcc,
    '规模效率': scale_eff,
    '超效率': super_eff
})
df = df.sort_values('超效率', ascending=False)
print(df.to_string(index=False))
```



------

### 案例 3：Malmquist 指数分析

**问题**：分析 5 个城市 2020—2023 年的生产率变化。

**Python 示例（简化）**：



```python
def malmquist_index(X_t, Y_t, X_t1, Y_t1):
    """
    简化 Malmquist 指数计算
    需要计算四个距离函数
    """
    # 第 t 期技术下的距离函数
    D_t_t = dea_ccr(X_t, Y_t)  # 第 t 期 DMU 在第 t 期技术下的效率
    D_t_t1 = dea_ccr(X_t, Y_t1)  # 第 t+1 期 DMU 在第 t 期技术下的效率
    D_t1_t = dea_ccr(X_t1, Y_t)  # 第 t 期 DMU 在第 t+1 期技术下的效率
    D_t1_t1 = dea_ccr(X_t1, Y_t1)  # 第 t+1 期 DMU 在第 t+1 期技术下的效率
    
    # Malmquist 指数
    M = np.sqrt((D_t_t1 / D_t_t) * (D_t1_t1 / D_t1_t))
    return M

# 示例数据（两期）
X_2020 = np.array([[10, 12, 8], [5, 6, 4]], dtype=float)
Y_2020 = np.array([[100, 110, 80]], dtype=float)
X_2023 = np.array([[12, 13, 9], [6, 7, 5]], dtype=float)
Y_2023 = np.array([[130, 140, 100]], dtype=float)

M = malmquist_index(X_2020, Y_2020, X_2023, Y_2023)
print(f"Malmquist 指数: {M}")
print(f"生产率变化: {'提高' if M.mean() > 1 else '下降'}")
```



------

### 案例 4：两阶段网络 DEA

**问题**：评价银行的两阶段效率：存款阶段（投入→存款）和盈利阶段（存款→利润）。

**Python 示例（简化）**：



```python
def two_stage_dea(X, Z, Y):
    """
    两阶段 DEA
    X: 投入 (m×n)
    Z: 中间产品 (p×n)
    Y: 最终产出 (s×n)
    """
    # 第一阶段效率（投入→中间）
    eff_stage1 = dea_ccr(X, Z)
    # 第二阶段效率（中间→产出）
    eff_stage2 = dea_ccr(Z, Y)
    # 整体效率
    eff_overall = eff_stage1 * eff_stage2
    return eff_stage1, eff_stage2, eff_overall

# 示例
X = np.array([[100, 120, 90], [50, 60, 45]], dtype=float)  # 投入
Z = np.array([[200, 250, 180]], dtype=float)  # 中间产品
Y = np.array([[80, 100, 70]], dtype=float)  # 产出

eff1, eff2, eff_all = two_stage_dea(X, Z, Y)
print(f"第一阶段效率: {eff1}")
print(f"第二阶段效率: {eff2}")
print(f"整体效率: {eff_all}")
```